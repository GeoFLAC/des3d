#!/usr/bin/env python3
"""Horton-Rogers-Lapwood linear stability of a porous layer heated from below.

Boussinesq Darcy flow, q = -(k/mu)(grad p + rho0*(1 - alpha*(T - T0))*g*e_z),
incompressible, with conduction and advection
C dT/dt + rho0*cf*q.grad T = lambda*lap T, C the bulk heat capacity.
Top and bottom: impermeable, fixed T; sides: impermeable, insulated.
A box of width L and height H admits theta ~ cos(m*pi*x/L)*sin(n*pi*z/H).
With a = m*pi*H/L and K2 = a^2 + (n*pi)^2, the growth rate is

    sigma = lambda/(C*H^2) * (Ra*a^2/K2 - K2),
    Ra = rho0*g*alpha*dT*k*H*rho0*cf/(mu*lambda).

Onset (sigma = 0) is Ra = K2^2/a^2, minimal 4*pi^2 at a = pi (L = H, m = n = 1).
Reference: Nield and Bejan, Convection in Porous Media, section 6.2.
"""
import math


def rayleigh(rho0, g, alpha, dT, k, H, cf, mu, conductivity):
    return rho0*g*alpha*dT*k*H*rho0*cf/(mu*conductivity)


def growth_rate(Ra, conductivity, capacity, H, L, m=1, n=1):
    a = m*math.pi*H/L
    K2 = a*a + (n*math.pi)**2
    return conductivity/(capacity*H*H)*(Ra*a*a/K2 - K2)


def critical_rayleigh(H, L, m=1, n=1):
    a = m*math.pi*H/L
    return (a*a + (n*math.pi)**2)**2/(a*a)


if __name__ == '__main__':
    assert abs(critical_rayleigh(1, 1) - 4*math.pi**2) < 1e-12
    assert abs(growth_rate(4*math.pi**2, 1, 1, 1, 1)) < 1e-12
    # The square cell is the most unstable single-cell box.
    assert all(critical_rayleigh(1, L) >= critical_rayleigh(1, 1) for L in (0.5, 0.9, 1.1, 2))
    # A doubled Ra above onset: sigma*C*H^2/lambda = Ra/2 - 2*pi^2 for a = pi.
    assert abs(growth_rate(8*math.pi**2, 1, 1, 1, 1) - 2*math.pi**2) < 1e-12
    print('convection reference: 4 checks pass')
