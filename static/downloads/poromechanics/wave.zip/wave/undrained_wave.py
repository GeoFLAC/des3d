#!/usr/bin/env python3
"""Measure the non-PT physical-inertia response of a closed saturated column.

The initial state has zero strain/pressure and a small sinusoidal velocity.
Zero permeability makes local fluid content constant. Compare the physical
undrained standing wave, not a quasistatic consolidation reference.
"""

import argparse
import configparser
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from Dynearthsol import Dynearthsol, YEAR2SEC, scan_frames


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(executable, folder, cfg, name):
    with (folder / f'{name}.cfg').open('w') as stream:
        cfg.write(stream)
    with (folder / f'{name}.log').open('w') as stream:
        subprocess.run([str(executable), f'{name}.cfg'], cwd=folder, check=True,
                       stdout=stream, stderr=subprocess.STDOUT, timeout=120,
                       env=dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1'))


def study(executable, output, spacing, steps, amplitude, samples=4, restart_check=False):
    output.mkdir(parents=True, exist_ok=False)
    (output / 'undrained_wave.py').write_bytes(Path(__file__).read_bytes())
    # All properties also appear in the generated input deck.
    bulk, shear, phi, alpha, fluid_bulk, grain_bulk = 1e7, 1e7, .3, 1., 2.17e9, 37e9
    density = (1-phi)*2650 + phi*1000
    storage = phi/fluid_bulk + (alpha-phi)/grain_bulk
    modulus = bulk + 4*shear/3 + alpha*alpha/storage
    speed = math.sqrt(modulus/density)
    period = 2/speed
    summary = dict(executable=str(executable), executable_sha256=digest(executable),
                   analyzer_sha256=digest(Path(__file__)),
                   source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                   reference=dict(storage_Pa_inv=storage, undrained_modulus_Pa=modulus,
                                  density_kg_m3=density, wave_speed_m_s=speed, period_s=period), cases={})
    patch = subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=ROOT)
    (output / 'source.diff').write_bytes(patch)
    summary['source_diff_sha256'] = hashlib.sha256(patch).hexdigest()
    for count in steps:
        folder = output / f'steps-{count}'
        folder.mkdir()
        cfg = configparser.ConfigParser(); cfg.optionxform = str
        cfg.read(ROOT / 'tests/functional/pt_hydrostatic_equilibrium.cfg')
        cfg['sim'].update(modelname='seed', max_steps='1', output_step_interval='1',
                          output_time_interval_in_yr='1', checkpoint_frame_interval='1',
                          has_initial_checkpoint='true', max_time_in_yr='1')
        cfg['mesh'].update(xlength=str(2*spacing), ylength=str(2*spacing), zlength='1',
                           resolution=str(spacing), meshing_elem_shape='1', remeshing_option='0')
        cfg['control'].update(has_PT='false', is_quasi_static='false', damping_option='0',
                              has_hydraulic_diffusion='true', has_thermal_diffusion='false',
                              has_moving_mesh='false', gravity='0', fixed_dt=repr(period/count),
                              is_using_mixed_stress='false', use_global_velocity_scaling='false')
        cfg['bc'].update(vbc_x1='1', vbc_z1='1', stress_bc_z1='0', stress_val_z1='0')
        for side in ('x0', 'x1', 'y0', 'y1', 'z0', 'z1'):
            cfg['bc'][f'hbc_{side}'] = '0'
        cfg['ic']['has_body_force_adjustment'] = 'false'
        cfg['mat'].update(bulk_modulus=f'[{bulk}]', shear_modulus=f'[{shear}]', porosity=f'[{phi}]',
                          biot_coeff=f'[{alpha}]', fluid_bulk_modulus=f'[{fluid_bulk}]',
                          bulk_modulus_s=f'[{grain_bulk}]', rho0='[2650]', fluid_rho0='[1000]',
                          hydraulic_perm='[0]', retention_model='[0]', alpha='[0]')
        run(executable, folder, cfg, 'seed')
        seed = Dynearthsol(str(folder / 'seed'))
        if seed.format != 'binary':
            raise RuntimeError('This checkpoint-initialization fixture currently requires binary output')
        x = seed.read_field(0, 'coordinate')
        conn = seed.read_field(0, 'connectivity')
        dim = seed.ndims
        assert not np.any(seed.read_field(0, 'pore pressure'))
        assert not np.any(seed.read_field(0, 'strain'))
        assert not np.any(seed.read_field(0, 'stress'))
        velocity = np.zeros_like(x)
        velocity[:, -1] = amplitude*np.sin(np.pi*(x[:, -1]+1))
        velocity[np.isclose(x[:, -1], -1) | np.isclose(x[:, -1], 0), -1] = 0
        seed.read_header(0)
        with Path(seed.get_fn(0)).open('r+b') as stream:
            stream.seek(seed.field_pos['velocity']); stream.write(velocity.astype(np.float64).tobytes())
        np.testing.assert_array_equal(seed.read_field(0, 'velocity'), velocity)
        cfg['sim'].update(modelname='wave', is_restarting='true', restarting_from_modelname=str(folder/'seed'),
                          restarting_from_frame='0', max_steps=str(count),
                          max_time_in_yr=repr(10*period/YEAR2SEC), output_step_interval=str(count//samples))
        run(executable, folder, cfg, 'wave')
        model = Dynearthsol(str(folder / 'wave'))
        rows = scan_frames(str(folder / 'wave'))
        volume = np.abs(np.linalg.det(x[conn][:, 1:]-x[conn][:, :1]))/math.factorial(dim)
        nodal_volume = np.zeros(len(x))
        np.add.at(nodal_volume, conn, np.broadcast_to((volume/(dim+1))[:, None], conn.shape))
        measured = []
        for row in rows:
            frame, time = row['frame'], row['time']
            v = model.read_field(frame, 'velocity')[:, -1]
            p = model.read_field(frame, 'pore pressure')
            strain = model.read_field(frame, 'strain')
            exact_v = amplitude*np.sin(np.pi*(x[:, -1]+1))*np.cos(2*np.pi*time/period)
            exact_p = -alpha*amplitude/(storage*speed)*np.cos(np.pi*(x[:, -1]+1))*np.sin(2*np.pi*time/period)
            eps = strain[:, :dim].sum(axis=1)
            projection = np.zeros(len(x))
            np.add.at(projection, conn, np.broadcast_to((volume*eps/(dim+1))[:, None], conn.shape))
            content = alpha*projection/nodal_volume + storage*p
            measured.append(dict(time_s=time, velocity_error_over_amplitude=float(np.max(np.abs(v-exact_v))/amplitude),
                                 pressure_error_over_amplitude=float(np.max(np.abs(p-exact_p))/(alpha*amplitude/(storage*speed))),
                                 max_local_fluid_content_error=float(np.max(np.abs(content))),
                                 local_content_error_over_strain_amplitude=float(np.max(np.abs(content))/(alpha*amplitude/speed))))
        summary['cases'][str(count)] = dict(dimension=dim, spacing_m=spacing, steps=count, dt_s=period/count,
                                           nodes=len(x), elements=len(conn), measured=measured,
                                           seed_save_sha256=digest(Path(seed.get_fn(0))),
                                           seed_checkpoint_sha256=digest(folder/'seed.chkpt.000000'),
                                           input_sha256=digest(folder/'wave.cfg'))
        if restart_check:
            sys.path.insert(0, str(ROOT/'tests/functional'))
            from pt_initial_checkpoint import fields
            quarter = next(r for r in rows if r['steps'] == count//4)
            cfg['sim'].update(modelname='resumed', restarting_from_modelname=str(folder/'wave'),
                              restarting_from_frame=str(quarter['frame']))
            run(executable, folder, cfg, 'resume')
            resumed = Dynearthsol(str(folder/'resumed'))
            original = {r['steps']:r for r in rows}
            for r in scan_frames(str(folder/'resumed')):
                fresh = original[r['steps']]
                assert r['time'] == fresh['time']
                names = ['coordinate', 'velocity', 'stress', 'strain', 'pore pressure', 'temperature']
                if r['steps'] > quarter['steps']:
                    names += ['force', 'strain-rate']
                    a = fields(folder/f'wave.chkpt.{fresh["frame"]:06d}')
                    b = fields(folder/f'resumed.chkpt.{r["frame"]:06d}')
                    for key in ('pending pore pressure increment', 'physical hydraulic step', 'dt'):
                        assert a[key] == b[key], key
                for name in names:
                    np.testing.assert_array_equal(model.read_field(fresh['frame'],name),
                                                  resumed.read_field(r['frame'],name))
            cfg['sim']['modelname']='wrong-order'
            cfg['control']['is_quasi_static']='true'
            with (folder/'wrong-order.cfg').open('w') as stream:cfg.write(stream)
            with (folder/'wrong-order.log').open('w') as stream:
                rejected=subprocess.run([str(executable),'wrong-order.cfg'],cwd=folder,
                    stdout=stream,stderr=subprocess.STDOUT,timeout=60)
            assert rejected.returncode == 22
            assert 'Hydraulic step ordering differs' in (folder/'wrong-order.log').read_text()
            summary['cases'][str(count)].update(restart_physical_fields_exact=True,
                                              incompatible_ordering_rejected=True)
        summary['cases'][str(count)]['outputs_sha256'] = {
            p.name: digest(p) for p in sorted(folder.glob('wave.*'))
            if p.suffix == '.info' or '.save.' in p.name or '.chkpt.' in p.name}
        (output / 'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False))
        print(count, 'maximum errors:', {
            key: max(r[key] for r in measured) for key in measured[0] if key != 'time_s'}, flush=True)
    if restart_check:
        # Verify compute_dt through a fresh, stationary solve, independently
        # measuring the smallest simplex height from its output coordinates.
        cfg['sim'].update(modelname='automatic', is_restarting='false', max_steps='1',
                          output_step_interval='1')
        cfg['control'].update(is_quasi_static='false', fixed_dt='0', dt_fraction='.8')
        run(executable, folder, cfg, 'automatic')
        auto = Dynearthsol(str(folder/'automatic'))
        points = auto.read_field(0,'coordinate')[auto.read_field(0,'connectivity')]
        volumes = np.abs(np.linalg.det(points[:,1:]-points[:,:1]))/math.factorial(dim)
        measures = []
        for omit in range(dim+1):
            face = np.delete(points,omit,axis=1)
            if dim == 2:
                measures.append(np.linalg.norm(face[:,1]-face[:,0],axis=1))
            else:
                measures.append(np.linalg.norm(np.cross(face[:,1]-face[:,0],face[:,2]-face[:,0]),axis=1)/2)
        height = np.min(dim*volumes/np.max(measures,axis=0))
        expected = .8*height/(5*speed)
        actual = scan_frames(str(folder/'automatic'))[1]['time']
        np.testing.assert_allclose(actual, expected, rtol=2e-14, atol=0)
        assert actual < .8*.5*height/math.sqrt(bulk/2650)
        summary['automatic_step'] = dict(expected_s=float(expected), actual_s=actual,
            matches_undrained_wave_limit=True, smaller_than_drained_limit=True,
            input_sha256=digest(folder/'automatic.cfg'))
        (output/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
    assert digest(executable) == summary['executable_sha256']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--spacing', type=float, default=.1)
    parser.add_argument('--steps', type=int, nargs='+', default=[256, 1024, 4096])
    parser.add_argument('--amplitude', type=float, default=1e-6)
    parser.add_argument('--samples', type=int, default=4)
    parser.add_argument('--restart-check', action='store_true')
    args = parser.parse_args()
    if (not math.isfinite(args.spacing) or args.spacing <= 0 or
            not math.isfinite(args.amplitude) or args.amplitude <= 0 or
            args.samples < 4 or args.samples % 4 or
            any(n < args.samples or n % args.samples for n in args.steps)):
        parser.error('Use positive finite spacing/amplitude and step counts divisible by the requested samples')
    study(args.executable.resolve(), args.output.resolve(), args.spacing, args.steps, args.amplitude,
          args.samples, args.restart_check)
