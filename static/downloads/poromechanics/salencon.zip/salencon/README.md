# salencon example

Run the input commands on the manual page from this folder. Inputs, meshes,
restart dependencies and measured records are preserved in this bundle.

Build DynEarthSol at reproduction revision [3774df0](https://github.com/GeoFLAC/DynEarthSol/tree/3774df00ba1708a4f70a836d2073f845653aac64).
The recorded executable/data hashes describe the measured runs, separately
from this reproduction revision.

Python runners, their shared helpers and references are maintained in the
[DES source](https://github.com/GeoFLAC/DynEarthSol/tree/3774df00ba1708a4f70a836d2073f845653aac64/benchmarks/poromechanics)
and [functional checks](https://github.com/GeoFLAC/DynEarthSol/tree/3774df00ba1708a4f70a836d2073f845653aac64/tests/functional/hydromechanics).
They are run from that complete checkout, not copied into this bundle.

Source files used by this example:

- [benchmarks/poromechanics/salencon_reference.py](https://github.com/GeoFLAC/DynEarthSol/blob/3774df00ba1708a4f70a836d2073f845653aac64/benchmarks/poromechanics/salencon_reference.py)
- [tests/functional/hydromechanics/check_kirsch.py](https://github.com/GeoFLAC/DynEarthSol/blob/3774df00ba1708a4f70a836d2073f845653aac64/tests/functional/hydromechanics/check_kirsch.py)
- [tests/functional/hydromechanics/check_salencon.py](https://github.com/GeoFLAC/DynEarthSol/blob/3774df00ba1708a4f70a836d2073f845653aac64/tests/functional/hydromechanics/check_salencon.py)
