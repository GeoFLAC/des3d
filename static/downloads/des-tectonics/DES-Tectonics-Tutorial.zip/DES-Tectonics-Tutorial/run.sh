#!/usr/bin/env bash
# Run one tutorial case from this directory:
#   ./run.sh core-complex            runs resources/models/core-complex.cfg in results/core-complex/
#   ./run.sh subduction --bg         the same in the background (the solver log is still written)
#   ./run.sh ex3-restart-fix         restarts the failed ex3-no-serpentinite run from its checkpoint
# Needs DYNEXE to point at your dynearthsol2d (resources/SETUP.md). OMP_NUM_THREADS is
# respected; it defaults to 4 here.
set -euo pipefail
cd "$(dirname "$0")"

case=${1:-}; bg=${2:-}
[ -n "$case" ] || { sed -n 2,7p "$0"; exit 1; }
[ -n "${DYNEXE:-}" ] && [ -x "$DYNEXE" ] || { echo "Set DYNEXE to your dynearthsol2d first (resources/SETUP.md, step 4)." >&2; exit 1; }
cfg=resources/models/$case.cfg
[ -f "$cfg" ] || { echo "No such case: $cfg. Cases: $(ls resources/models/*.cfg | xargs -n1 basename | sed 's/.cfg$//' | tr '\n' ' ')" >&2; exit 1; }
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-4}

dir=results/$case
if [ -n "$(ls $dir/output 2>/dev/null)" ] && [ "$case" != ex3-restart-fix ]; then
    echo "$dir/output already holds results; move it away or pick another case." >&2; exit 1
fi
mkdir -p $dir/output
log=solver.log
if [ "$case" = ex3-restart-fix ]; then
    # A restart continues ex3-no-serpentinite from its frame-60 checkpoint (3.0 Myr). The failed
    # run's output is copied here first: yours if you made it, else the supplied reference.
    parent=results/ex3-no-serpentinite/output
    [ -f $parent/model.chkpt.000060.vtkhdf ] || parent=resources/reference/ex3-no-serpentinite/output
    cp $parent/model.* $dir/output/
    echo "Restarting from $parent (frame 60)"
    log=restart.log
fi
cp "$cfg" "$dir/"
grep -q poly_filename "$cfg" && cp resources/models/poly-subduction.poly "$dir/"

cd "$dir"
echo "Running $case.cfg with $OMP_NUM_THREADS threads in $PWD; log: $log"
if [ "$bg" = "--bg" ]; then
    nohup "$DYNEXE" "$case.cfg" > "$log" 2>&1 &
    echo "Started in the background, PID $!. Follow it with: tail -f $PWD/$log"
else
    "$DYNEXE" "$case.cfg" 2>&1 | tee "$log"
fi
