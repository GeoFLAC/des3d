# Tectonic rifting and subduction with DynEarthSol

A 90-minute class. Open **Tutorial.html** to read it or **Tutorial.ipynb** to
work through it. The web version of the tutorial, with the same figures, is at
https://geoflac.github.io/des3d/docs/tutorial/tectonics.

## Quick start

```bash
# once, before the class (resources/SETUP.md has the details, about 20 minutes)
export DYNEXE="/absolute/path/to/DynEarthSol-tutorial/dynearthsol2d"
./run.sh subduction --bg            # the 25-40 minute Part 2 run; let it go while you read
source .venv/bin/activate && python -m jupyterlab    # opens Tutorial.ipynb
```

Every run is one command, `./run.sh <case>`, where `<case>` is a file in
`resources/models/` without `.cfg`; it writes to `results/<case>/`. The notebook
only reads and plots. Its first code cell uses your run when `results/<case>/output/`
has frames and the supplied reference otherwise, so nothing in the class waits
for a run to finish.

## In the class

1. Follow `resources/SETUP.md` before the class: build DES with MMG and HDF5,
   create the Python environment, start the subduction run in the background.
2. Part 1 runs `./run.sh core-complex` to 100 kyr, 10 to 15 minutes. While it
   runs, read the notebook's Part 1 with the supplied reference results.
3. Exercises 1 and 2 compare runs that have already been made for you. Running
   one yourself is optional; each takes 1 to 15 minutes.
4. Part 2 analyses the subduction run you started before the class, or the
   supplied reference if it has not finished. Exercise 3 and the troubleshooting
   case use supplied results; the troubleshooting restart is a 10 minute run you
   can try.

After each run the notebook shows how to open the frames in ParaView, or convert
them with DES's `2vtk.py` for VisIt.

## What is in the package

| Folder | Contents |
| --- | --- |
| `run.sh` | Launches one case: makes `results/<case>/output/`, copies the config there, runs DES and logs to `solver.log` (`--bg` for the background) |
| `resources/models/` | The two base configurations, the subduction mesh file, and one config per exercise variant |
| `resources/reference/<run>/` | For every run: a few saved frames stripped to the fields the notebook plots, the `.info` table, `series.csv` with per-frame summaries, and for three runs `remesh.csv`, the remesh events the remeshing plots read |
| `resources/tutorial_tools.py` | The plotting and reading helpers the notebook calls, about 400 lines of plain numpy, h5py and matplotlib |

Supplied runs, all made with 6 threads on a 2024 laptop (times on 4 threads are
about a third longer):

| Case (`./run.sh <case>`) | Who runs it | Time | Supplied frames |
| --- | --- | --- | --- |
| `core-complex` | you, at the start of the class | 12 min | 0, 25, 50, 75 and 100 kyr |
| `ex1-diffusivity-1e-6`, `-1e-5` | optional | 5 to 8 min | last frame |
| `ex2-smallest-size-1`, `-0.001`, `-0.001-coeff-10` | optional | 1 to 16 min | last frame |
| `subduction` | you, before the class | 23 min | 0, 0.5, 1, 2.5 and 5 Myr |
| `ex3-no-serpentinite` | supplied (fails on purpose at 3.45 Myr) | 20 min | 0, 3.0 Myr with its checkpoint, and the last frame |
| `ex3-thickness-10km` | supplied | 23 min | last frame |
| `ex3-restart-fix` | optional | 10 min | 5 Myr; its `.info` starts at frame 60 |

To keep the download small, each supplied run has only a few frames, and
those hold only the fields the notebook plots, so they do not open in ParaView
and `2vtk.py` cannot convert them. The time-series plots read `series.csv`,
computed from every frame of the full run. Your own runs have everything and
the notebook computes the same series from them.

Save your runs under `results/`, one directory per run, each with an `output/`
folder. Figures you export with `tt.save_figure` go to `results/figures/`.
