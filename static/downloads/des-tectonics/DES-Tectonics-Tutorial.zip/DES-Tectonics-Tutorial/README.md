# Tectonic rifting and subduction with DynEarthSol

A one-day, hands-on tutorial: Part 1 grows a metamorphic core complex, Part 2
runs a subduction zone. Read **Tutorial.html** in a browser, or work through
**Tutorial.ipynb** in JupyterLab. The web version, with more background, is at
https://geoflac.github.io/des3d/docs/tutorial/tectonics.

## Before the day (about 20 minutes)

Follow `resources/SETUP.md`. In short, from this directory:

```bash
git clone https://github.com/GeoFLAC/DynEarthSol.git DynEarthSol
cd DynEarthSol
make ndims=2 usemmg=1 hdf5=1 -j4
cd ..
./setup_env.sh                       # the Python environment for JupyterLab, in .venv/
```

The build must be 2D with MMG. A DES built for another tutorial with a plain
`make` is 3D without MMG and cannot run this one.

## On the day

Start JupyterLab from this directory:

```bash
source .venv/bin/activate && python -m jupyterlab
```

It opens with `Tutorial.ipynb` and a terminal side by side. Runs are started
from the terminal (File → New → Terminal opens another). The notebook runs
nothing itself; each panel shows your run once it has written that
panel's frame and the supplied reference until then, so you never wait for
a run to finish.

### Once in each new terminal

```bash
export OMP_NUM_THREADS=4                   # CPU cores DES may use; raise it if you have more to spare
DES=$PWD/DynEarthSol/dynearthsol2d         # the DES executable; or the path of a DES built elsewhere
```

Both lines assume the terminal is in this directory, where JupyterLab
terminals start.

### Run a case

Each case is a config in `resources/models/` and runs in its own directory
under `results/`. For `core-complex.cfg`:

```bash
mkdir -p results/core-complex/output                  # DES writes its frames into output/
cp resources/models/core-complex.cfg results/core-complex/
cd results/core-complex
"$DES" core-complex.cfg
cd ../..
```

DES runs inside the case's directory and prints its progress to the terminal.
When the run ends, `cd ../..` brings you back to this
directory. For another case, replace `core-complex` with the case's name
throughout.

The subduction cases (`subduction`, `ex3-*`) also need their mesh file, so
their `cp` line copies it too, for example:

```bash
cp resources/models/subduction.cfg resources/models/poly-subduction.poly results/subduction/
```

The restart case is set up differently; the notebook shows how.

### While it runs

The run occupies its terminal until it ends with `Ending simulation.` and a time
summary. Ctrl-C stops it early; the terminal then stays in the case's
directory, so type `cd ../..` to come back. To see from another terminal how
far a run has got, list the frames it has written (`model.save.NNNNNN.vtkhdf`,
one per saved frame):

```bash
ls results/core-complex/output
```

Runs at the same time share the machine's cores, so start the next one when a
run finishes, or lower `OMP_NUM_THREADS`. To run a case again, move the old one
away first: `mv results/core-complex results/core-complex-old`.

### Schedule

| Slot | What you do | Start these runs |
| --- | --- | --- |
| Morning, 75 min | Part 1 and Exercises 1–2 | `core-complex` at once; one `ex1-*` and one `ex2-*` |
| Lunch | | `subduction` |
| Afternoon, 75 min | Part 2 and Exercise 3 | optionally one `ex3-*` |
| Afternoon, 90 min | Restart case, ParaView, your own changes | `restart-stop`, anything you add to `resources/models/` |

## Run times

Measured with 6 threads on an Apple M3 Max; with 4 threads, allow about a
third longer.

| Case | Time | Reference frames supplied |
| --- | --- | --- |
| `core-complex` | 12 min | 0, 25, 50, 75, 100 kyr |
| `ex1-diffusivity-1e-6`, `-1e-5` | 4–8 min | last |
| `ex2-smallest-size-1`, `-0.001`, `-0.001-coeff-10` | 1–14 min | last |
| `subduction` | 22 min | 0, 0.5, 1, 2.5, 5 Myr |
| `ex3-no-serpentinite`, `ex3-thickness-10km` | 17–21 min | last |
| `restart-stop` | 2 min | 6, 7 Myr |

The references were made on DynEarthSol `master` of 30 October 2026.

## What is in the package

| Path | Contents |
| --- | --- |
| `setup_env.sh` | Creates the Python environment for JupyterLab (`.venv/`), which opens with the notebook and a terminal side by side (`resources/jupyterlab-workspace.json`) |
| `resources/models/` | The configs of both parts and of every exercise variant, and the subduction mesh file |
| `resources/reference/` | Trimmed results of every case (see below) |
| `resources/figures/` | The model-setup sketches the notebook shows, the same as on the web page |
| `resources/tutorial_tools.py` | The reading and plotting helpers the notebook calls (numpy, h5py, matplotlib) |
| `resources/SETUP.md` | Build and Python setup |
| `results/` | Not shipped: your runs, one directory per case |

**The references are trimmed.** To keep the download small, each reference
keeps only a few frames and only the fields the notebook plots, so ParaView
and `2vtk.py` cannot open them. Use your own runs for those. The exception is
the subduction run's frame 100, shipped whole with its checkpoint so that
`restart-stop` can start from it.
