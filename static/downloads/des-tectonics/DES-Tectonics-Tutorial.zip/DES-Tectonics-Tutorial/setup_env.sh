#!/usr/bin/env bash
# Prepare the Python environment for the tutorial notebook, once, before the day:
#   ./setup_env.sh
# It creates .venv/ in this directory and installs resources/requirements.txt into it.
# Running it again reuses .venv/ and only installs what is missing.
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
    echo "Creating the Python environment in .venv/ with $(python3 --version)"
    python3 -m venv .venv
fi
.venv/bin/python -m pip install -r resources/requirements.txt
.venv/bin/python -c "import numpy, scipy, matplotlib, h5py, jupyterlab"

# JupyterLab from this environment, started in this directory, opens with Tutorial.ipynb
# and a terminal side by side (resources/jupyterlab-workspace.json). Its layout is kept
# inside .venv/, so other JupyterLab installations are not affected. A layout already
# there (your own arrangement, saved as you work) is kept.
workspaces=$PWD/.venv/share/jupyter/lab/workspaces
layout=$workspaces/$(.venv/bin/python -c "from jupyterlab_server.workspaces_handler import slugify; print(slugify('default'))").jupyterlab-workspace
mkdir -p "$workspaces"
[ -f "$layout" ] || cp resources/jupyterlab-workspace.json "$layout"
printf '{"LabApp": {"workspaces_dir": "%s"}}\n' "$workspaces" > .venv/etc/jupyter/jupyter_server_config.json

echo
echo "Python environment ready. To start the tutorial, from this directory:"
echo "  source .venv/bin/activate && python -m jupyterlab"
