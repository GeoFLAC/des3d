# Preparation

Do this before the class. It takes about 20 minutes, most of it compiling.
Use Linux, macOS or Windows Subsystem for Linux (WSL); on Windows run both
DES and Jupyter inside WSL.

## 1. System packages

**Ubuntu 22.04 or later (including WSL):**

```bash
sudo apt update
sudo apt install -y git g++ make cmake libboost-program-options-dev libhdf5-dev python3 python3-venv
```

**macOS:** install the Xcode Command Line Tools (`xcode-select --install`) and
[Homebrew](https://brew.sh/), then:

```bash
brew install boost libomp hdf5 cmake python
```

`cmake` builds the MMG remesher, which `make` fetches as a git submodule.
HDF5 is needed because the notebook reads DES's VTKHDF output.

## 2. Build DES

Part 1 runs on DynEarthSol `master`. Part 2 needs the branch of
[pull request #110](https://github.com/GeoFLAC/DynEarthSol/pull/110) until it
is merged; the same build command works for both, so build the branch and you
have everything.

```bash
git clone https://github.com/GeoFLAC/DynEarthSol.git DynEarthSol-tutorial
cd DynEarthSol-tutorial
git checkout feature/virtual-topology     # skip this line for Part 1 only, once PR #110 has merged
make ndims=2 usemmg=1 hdf5=1 -j4
export DYNEXE="$PWD/dynearthsol2d"
"$DYNEXE" --help | grep -c mmg_metric_refine_coeff   # 1 or more means the build is right
echo "$DYNEXE"                                         # copy this path for step 4
```

`make` fetches and builds MMG itself; `usemmg=1` is required because the
subduction example restores its side walls, which only MMG supports. If
`make` cannot find Boost or HDF5, run `make config ndims=2 usemmg=1 hdf5=1`
and check the paths it prints; on macOS it detects the Homebrew prefixes.

## 3. Python

In the extracted `DES-Tectonics-Tutorial` directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r resources/requirements.txt
python -m jupyterlab
```

Open `Tutorial.ipynb`. Its first code cell checks that it is running inside
the tutorial directory and tells you which runs it will plot.

The requirements include `scipy` for DES's `2vtk.py`, which converts a run's
frames to `.vtu` and `.vtp` files for ParaView or VisIt. ParaView can also open
your own runs' `.vtkhdf` frames directly, so a viewer is optional but worth having:
https://www.paraview.org/download/.

## 4. Before the class starts

Open a terminal in JupyterLab (File → New → Terminal) and run, with your own
path:

```bash
export DYNEXE="/absolute/path/to/DynEarthSol-tutorial/dynearthsol2d"
export OMP_NUM_THREADS=4
```

Then start the longest run so it is ready when the class reaches it:

```bash
./run.sh subduction --bg
```

It runs in `results/subduction/` and takes 25 to 40 minutes depending on the
machine; `tail -f results/subduction/solver.log` follows it. Everything in the
notebook also works on the supplied reference results, so nothing depends on
this run finishing.
