# Setup

Do this before the tutorial day. It takes about 20 minutes, most of it
compiling. Use Linux, macOS or Windows Subsystem for Linux (WSL); on Windows,
run both DES and Jupyter inside WSL.

Everything goes inside the extracted `DES-Tectonics-Tutorial` directory:

```
DES-Tectonics-Tutorial/
├── DynEarthSol/        DES, cloned and built in step 2
├── .venv/              the Python environment, made by setup_env.sh in step 3
├── Tutorial.ipynb      the notebook
├── resources/          configs, reference results, helpers
└── results/            your runs, one directory per case
```

## 1. System packages

**Ubuntu 22.04 or later (including WSL):**

```bash
sudo apt update
sudo apt install -y git g++ make cmake libboost-program-options-dev libhdf5-dev python3 python3-venv
```

**macOS:** install the Xcode Command Line Tools (`xcode-select --install`) and
[Homebrew](https://brew.sh/), then:

```bash
brew install boost libomp hdf5 cmake python
```

## 2. Build DES

In the `DES-Tectonics-Tutorial` directory:

```bash
git clone https://github.com/GeoFLAC/DynEarthSol.git DynEarthSol
cd DynEarthSol
make ndims=2 usemmg=1 hdf5=1 -j4
./dynearthsol2d --help | grep -c serpentinization   # must print 1 or more
cd ..
```

- `make` fetches and builds the MMG remesher itself (that is what `cmake` is
  for). `usemmg=1` is required: the subduction model restores its side walls,
  which only MMG supports. `hdf5=1` writes the output the notebook reads.
- If the `grep` prints 0, the clone predates the phase-change engine Part 2
  uses (merged 30 October 2026, [pull request #110](https://github.com/GeoFLAC/DynEarthSol/pull/110)):
  `git pull` and run `make` again.
- If `make` cannot find Boost or HDF5, run `make config ndims=2 usemmg=1 hdf5=1`
  and check the paths it prints.

**Already have a recent 2D MMG build elsewhere?** Skip the clone. On the day,
set `DES` to the path of its `dynearthsol2d` (README, "Once in each new
terminal"), give the notebook's first code cell the same path,
`tt.check_executable("/path/to/dynearthsol2d")`, and replace `DynEarthSol/` in
the notebook's `2vtk.py` commands with your clone's path.

## 3. Python

In the `DES-Tectonics-Tutorial` directory:

```bash
./setup_env.sh
```

It creates a Python environment in `.venv/` and installs the packages of
`resources/requirements.txt` into it (numpy, scipy, matplotlib, h5py and
JupyterLab), a few minutes the first time. Running it again only installs what
is missing. It also sets JupyterLab up to open with `Tutorial.ipynb` and a
terminal side by side when started from this directory; that setting lives inside
`.venv/` and leaves any other JupyterLab alone. Then start JupyterLab, the same
command you will use on the day:

```bash
source .venv/bin/activate && python -m jupyterlab
```

Run the notebook's first code cell. It checks the DES
executable, says whether the build is recent enough for Part 2, and lists
which runs it will plot. If it reports no problem, you are ready.

JupyterLab remembers how you arrange its tabs. To get the starting layout back,
delete `.venv/share/jupyter/lab/workspaces/` and run `./setup_env.sh` again.

## 4. Optional: ParaView

To explore your own runs interactively, install ParaView from
https://www.paraview.org/download/. It opens DES's `.vtkhdf` frames directly.
VisIt users convert them first with DES's `2vtk.py` (the notebook shows how).

## On the day

The README's "On the day" section has the terminal commands: the two lines to
set in each new terminal, the commands that run a case, and how to check on a run.
