"""Small, inspectable helpers for the DES tectonics tutorial notebook.

Everything reads the VTKHDF frames a DES run writes (``output/model.save.NNNNNN.vtkhdf``) plus
its ``output/model.info`` table, with h5py and numpy alone. A run directory is any folder that
holds an ``output/`` subfolder, so your own runs and the supplied reference runs are read the
same way.
"""
from pathlib import Path
import csv
import functools
import re
import textwrap

import h5py
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from matplotlib.collections import PolyCollection
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "resources"
REFERENCE = DATA / "reference"
YEAR = 365.2422 * 86400.0           # DES constants.hpp YEAR2SEC
BOUNDZ1 = 32                        # DES constants.hpp: the top-boundary bit of bcflag
PLS_BAND = 0.5                      # an element with more plastic strain than this is "in the fault band"
MARK_REFERENCE = True               # tag what is drawn from a supplied reference; src/make_figures.py turns it off
REF_TAG_CLEAR = (0, 0.08)           # anchor of a lower-left legend, clear of the reference tag below it

MAT_NAMES = ["oceanic crust", "cont. crust", "mantle", "sediment", "serpentinite",
             "eclogite", "hydrous mantle", "sediment rock", "metasediment", "schist"]
MAT_COLORS = ["#2166ac", "#d8b365", "#dfe9df", "#f2c94c", "#9b59d0",
              "#d73027", "#66c2a5", "#e6ab02", "#a65628", "#999999"]
ARM_COLORS = ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e"]


def configure_plotting():
    plt.rcParams.update({"font.size": 11, "axes.titlesize": 12, "figure.dpi": 110,
                         "savefig.dpi": 160, "axes.spines.top": False, "axes.spines.right": False})


# ---------------------------------------------------------------- the DES executable

def check_executable(path=None):
    """The DES executable, or None, with a report of what to do. Without ``path`` this is
    DynEarthSol/dynearthsol2d in the tutorial directory, the build of SETUP.md step 2.
    Part 2 needs the phase-change engine merged on 30 October 2026, which shows as
    serpentinization parameters in --help.
    """
    import os
    import subprocess
    exe = Path(path).expanduser() if path else ROOT / "DynEarthSol" / "dynearthsol2d"
    shown = exe.relative_to(ROOT) if exe.is_relative_to(ROOT) else exe     # short when inside this directory
    if not os.access(exe, os.X_OK):
        print(f"No DES executable at {shown}.\n"
              f"Build DES inside this directory (\"Optional: download and build DES\" above, or\n"
              f"resources/SETUP.md step 2), or give this cell the path of a DES built elsewhere:\n"
              f"  tt.check_executable(\"/path/to/dynearthsol2d\")")
        return None
    out = subprocess.run([str(exe), "--help"], capture_output=True, text=True).stdout
    print(f"DES executable: {shown}")
    if "serpentinization" in out:
        print("Part 2 ready: --help lists the serpentinization parameters.")
    else:
        print("Too old for Part 2: --help has no serpentinization parameters. git pull in the clone and rebuild.")
    return exe


# ---------------------------------------------------------------- reading a run

def frames(run):
    """Sorted frame numbers of a run directory (its output/model.save.*.vtkhdf files)."""
    run = Path(run)
    return sorted(int(p.name[-13:-7]) for p in (run / "output").glob("model.save.*.vtkhdf"))


def is_reference(run):
    """True for a supplied reference run, False for a run of your own."""
    return Path(run).resolve().is_relative_to(REFERENCE.resolve())


def finished(run):
    """True once a run has reached the last frame of the supplied reference of its name; always
    True for a reference, or a run with no reference of its name."""
    run = Path(run)
    ref = REFERENCE / run.name
    if is_reference(run) or not ref.is_dir():
        return True
    own = frames(run)
    return bool(own) and own[-1] >= frames(ref)[-1]


def written(run):
    """The frames of a run that are complete: all of them once it has finished, else all but the
    newest, which may be half written; it counts once the next one is out."""
    own = frames(run)
    return own if finished(run) else own[:-1]


def partial(run):
    """True for a run of yours that has written frames but not finished."""
    return not finished(run) and bool(written(run))


def source(run, frame=None):
    """The run directory to read ``frame`` from: your own run once it has written that frame, else
    the supplied reference of the same name. Without ``frame``, the whole run (last frame, remesh
    count): your own run only once it has finished. A reference, or a run with no reference of
    its name, is returned as it is."""
    run = Path(run)
    if finished(run) or (frame is not None and frame in written(run)):
        return run
    return REFERENCE / run.name


def mark_reference(ax, run, right=False):
    """Tag a panel drawn from a supplied reference in black at its lower-left corner (a material
    legend there sits just above it, at REF_TAG_CLEAR), or its lower-right one."""
    if MARK_REFERENCE and is_reference(run):
        ax.text(0.992 if right else 0.008, 0.015, "reference", transform=ax.transAxes,
                ha="right" if right else "left", va="bottom", fontsize=9.5,
                color="black", fontweight="bold", zorder=12,
                bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.85))


def source_label(label, run):
    """A label, with "(reference)" added for a supplied reference run."""
    return f"{label} (reference)" if MARK_REFERENCE and is_reference(run) else label


def info(run):
    """The .info table: frame, step, time (s), dt (s), wall time (s), nnode, nelem, nseg."""
    a = np.atleast_2d(np.loadtxt(Path(run) / "output/model.info"))
    return dict(frame=a[:, 0].astype(int), step=a[:, 1].astype(int), t_yr=a[:, 2] / YEAR,
                dt_s=a[:, 3], wall_s=a[:, 4], nnode=a[:, 5].astype(int), nelem=a[:, 6].astype(int))


def load(run, frame):
    """One frame: coordinates (km), connectivity, element fields, nodal fields and the markers."""
    with h5py.File(Path(run) / f"output/model.save.{frame:06d}.vtkhdf", "r") as h:
        sr = h["strain-rate"][...]
        d = dict(x=h["coordinate"][...] / 1e3, c=h["connectivity"][...], bc=h["bcflag"][...],
                 pls=h["plastic strain"][...], mat=h["material"][...].astype(int),
                 visc=h["viscosity"][...], T=h["temperature"][...],
                 srII=np.sqrt(0.5 * (sr[:, 0] ** 2 + sr[:, 1] ** 2) + sr[:, 2] ** 2),
                 vel=h["velocity averaged"][...] if "velocity averaged" in h else h["velocity"][...],
                 z0=-h["coord0"][...][:, 1] / 1e3,            # each node's initial depth, km
                 t_yr=float(h["time_yr"][0]))
        if "markerset.coord" in h:
            d["mx"] = h["markerset.coord"][...] / 1e3
            d["mm"] = h["markerset.mattype"][...].astype(int)
    return d


def element_classes(d):
    """Element counts with no plastic strain (< 0.01), softening (0.01 to pls1) and fully softened
    (> pls1); pls1 is 0.1 in the subduction box (wider than 300 km), 0.5 in Part 1's."""
    xs, _ = surface(d)
    e, pls1 = d["pls"], 0.1 if xs.max() - xs.min() > 300 else 0.5
    return int((e < 0.01).sum()), int(((e >= 0.01) & (e < pls1)).sum()), int((e >= pls1).sum())


def surface(d):
    """x and z (km) of the free-surface nodes, sorted by x."""
    top = (d["bc"] & BOUNDZ1) != 0
    o = np.argsort(d["x"][top, 0])
    return d["x"][top, 0][o], d["x"][top, 1][o]


def element_edge(d):
    """Equivalent equilateral edge length (km) of every element, from its area."""
    tri = d["x"][d["c"]]
    area = 0.5 * np.abs((tri[:, 1, 0] - tri[:, 0, 0]) * (tri[:, 2, 1] - tri[:, 0, 1])
                        - (tri[:, 2, 0] - tri[:, 0, 0]) * (tri[:, 1, 1] - tri[:, 0, 1]))
    return np.sqrt(4 * area / np.sqrt(3))


def band_dip(d):
    """Dip (degrees) of the fault band: a least-squares line through the centroids of elements
    with plastic strain above PLS_BAND."""
    cen = d["x"][d["c"]].mean(1)
    m = d["pls"] > PLS_BAND
    if m.sum() < 5:
        return np.nan
    return np.degrees(np.arctan(abs(np.polyfit(cen[m, 0], cen[m, 1], 1)[0])))


def series(run):
    """Per-frame summary of a run as a dict of arrays. Reads resources' series.csv when the run
    is a supplied reference (its frames are few and stripped), else computes from every written frame."""
    run = Path(run)
    csv_path = run / "series.csv"
    if csv_path.is_file():
        with csv_path.open() as f:
            rows = list(csv.DictReader(f))
        return {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}
    frame_list = written(run)
    ref = REFERENCE / run.name
    if (ref / "series.csv").is_file():
        # a restart's output/ also holds the parent's frames it was copied from: start where the reference does
        frame_list = [fr for fr in frame_list if fr >= series(ref)["frame"][0]]
    return _series_from_frames(str(run), tuple(frame_list))


@functools.lru_cache(maxsize=32)
def _series_from_frames(run, frame_list):
    """series() of your own run, computed from its frames; cached on the frame list, so a plot
    cell rerun while the run goes on reads only once the frames it has read before."""
    rows = []
    for fr in frame_list:
        d = load(run, fr)
        xs, zs = surface(d)
        if xs.max() - xs.min() > 300:          # the subduction box: keep 60 km clear of the side walls,
            zs = zs[(xs > xs.min() + 60) & (xs < xs.max() - 60)]   # which a restored or held wall can warp
        none, softening, softened = element_classes(d)
        row = dict(frame=fr, t_kyr=d["t_yr"] / 1e3, t_myr=d["t_yr"] / 1e6, nelem=len(d["pls"]),
                   n_pls_none=none, n_pls_softening=softening, n_pls_softened=softened,
                   crest_km=zs.max(), basin_km=zs.min(), relief_km=zs.max() - zs.min(),
                   max_plastic_strain=d["pls"].max(), band_dip_deg=band_dip(d),
                   trench_km=zs.min(), relief_max_km=zs.max())
        if "mm" in d:
            slab = (d["mm"] == 0) | (d["mm"] == 5)
            deep = ((d["mat"] == 0) | (d["mat"] == 5)) & (d["x"][d["c"]][:, :, 1].mean(1) < -60)   # slab elements below 60 km
            row.update(slab_tip_km=d["mx"][slab, 1].min() if slab.any() else np.nan,
                       slab_T_deep_C=d["T"][d["c"][deep]].mean() - 273.15 if deep.any() else np.nan,
                       n_serpentinite=int((d["mm"] == 4).sum()), n_eclogite=int((d["mm"] == 5).sum()))
        rows.append(row)
    return {k: np.array([r.get(k, np.nan) for r in rows]) for k in rows[0]}


def remesh_events(run):
    """(time in yr, trigger, elements before, after) of each remesh, from the run's solver.log,
    or from remesh.csv when the run is a supplied reference (its log is not shipped)."""
    csv_path = Path(run) / "remesh.csv"
    if csv_path.is_file():
        with csv_path.open() as f:
            return [(float(r["time"]), r["trigger"], float(r["nelem_before"]), float(r["nelem_after"]))
                    for r in csv.DictReader(f)]   # element counts are NaN for a remesh that failed
    logs = [p for p in (Path(run) / "solver.log", Path(run) / "output/model.runlog") if p.is_file()]
    if not logs:
        return []
    text = logs[0].read_text(errors="replace")
    triggers = {"tiny element": r"is too small", "low quality": r"is too low",
                "bottom drift": r"too far from the bottom", "side-wall drift": r"too far from the [xy][01] side"}
    out, prev = [], 0
    for m in re.finditer(r"Remeshing starts \(#\d+, step \d+, t = ([0-9.eE+-]+) yr\)", text):
        before = text[prev:m.start()]
        last = max(((h.start(), k) for k, pat in triggers.items() for h in re.finditer(pat, before)), default=None)
        nm = re.compile(r"New mesh \([^)]*\): nodes \d+ -> \d+, elements (\d+) -> (\d+)").search(text, m.end())
        a, b = (int(nm.group(1)), int(nm.group(2))) if nm else (np.nan, np.nan)
        out.append((float(m.group(1)), last[1] if last else "other", a, b))
        prev = m.end()
    return out


def plot_series(ax, run, x, y, label=None, scale=1, **kw):
    """Plot column y (times scale) of a run's series() against column x. A run of yours that has not finished
    is drawn over its reference, which stays faded in the background, so its line grows along the
    reference as frames come in. Returns the series of the whole run: yours once it has finished,
    else the reference's."""
    run = Path(run)
    whole = series(source(run))
    if not partial(run):
        ax.plot(whole[x], whole[y] * scale, label=source_label(label, source(run)) if label else None, **kw)
        return whole
    ax.plot(whole[x], whole[y] * scale, alpha=0.3, label=source_label(label, REFERENCE / run.name) if label else None, **kw)
    own = series(run)
    ax.plot(own[x], own[y] * scale, label=label, **kw)
    return whole


def run_legend(fig, runs, labels):
    """One legend for a comparison figure's bottom row of line plots, below that row: your runs in
    the first row, the references in the second (faded under a run of yours still going), each
    under its own run; an empty row is left out."""
    blank = Line2D([], [], alpha=0, label=" ")
    yours, refs = [], []
    for r, lab, c in zip(runs, labels, ARM_COLORS):
        own = partial(r) or not is_reference(source(r))
        yours.append(Line2D([], [], color=c, lw=2, label=lab) if own else blank)
        refs.append(Line2D([], [], color=c, lw=2, alpha=0.3 if partial(r) else 1, label=source_label(lab, REFERENCE / r.name))
                    if partial(r) or not own else blank)
    rows = [row for row in (yours, refs) if any(h is not blank for h in row)]
    fig.legend(handles=[h for column in zip(*rows) for h in column], loc="outside lower center",
               ncol=len(runs), fontsize=9, frameon=False)


# ---------------------------------------------------------------- running DES

def velocity_arrows(ax, d, box, n_across=20, ref_cm_yr=3.0, span=0.64, color="#444"):
    """Arrows of the velocity on a regular grid inside box (x0, x1, z0, z1 in km)."""
    x0, x1, z0, z1 = box
    dl = (x1 - x0) / n_across
    gx, gz = np.meshgrid(np.arange(x0 + dl / 2, x1, dl), np.arange(z0 + dl / 2, z1, dl))
    tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
    u = mtri.LinearTriInterpolator(tri, d["vel"][:, 0] * 100 * YEAR)(gx, gz)
    w = mtri.LinearTriInterpolator(tri, d["vel"][:, 1] * 100 * YEAR)(gx, gz)
    keep = ~(np.ma.getmaskarray(u) | np.ma.getmaskarray(w))
    gx, gz, u, w = gx[keep], gz[keep], np.asarray(u)[keep], np.asarray(w)[keep]
    speed = np.hypot(u, w)
    f = np.where(speed > 2 * ref_cm_yr, 2 * ref_cm_yr / np.maximum(speed, 1e-30), 1.0)
    return ax.quiver(gx, gz, u * f, w * f, color=np.where(speed > 2 * ref_cm_yr, "#b2182b", color).tolist(),
                     angles="xy", scale_units="xy", scale=ref_cm_yr / (span * dl), width=0.0025,
                     headwidth=3.5, headlength=4, zorder=6)


def draw_plastic_strain(ax, d, vmax=3, mesh=True):
    """Plastic strain on the mesh with the surface drawn; returns the mappable."""
    tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
    pc = ax.tripcolor(tri, facecolors=d["pls"], cmap="magma", vmin=0, vmax=vmax,
                      edgecolors="w" if mesh else "none", linewidth=0.15)
    xs, zs = surface(d)
    ax.plot(xs, zs, color="#222", lw=0.9)
    ax.set_facecolor("#f7f6f2")
    ax.set_aspect("equal")
    return pc


def draw_material(ax, d, markers=(4, 5)):
    """Element material with the chosen marker materials as dots and the surface drawn."""
    ax.add_collection(PolyCollection(d["x"][d["c"]], facecolors=[MAT_COLORS[m] for m in d["mat"]], edgecolors="none"))
    for m, col in zip(markers, ("#5e1a8e", "#a50f15")):
        sel = d["mm"] == m
        ax.plot(d["mx"][sel, 0], d["mx"][sel, 1], ".", ms=2.4, color=col, rasterized=True)
    xs, zs = surface(d)
    ax.plot(xs, zs, color="#222", lw=0.8)
    ax.set_facecolor("#f7f6f2")
    ax.set_aspect("equal")


def plot_core_complex(run, times_kyr=(25, 50, 75, 100), xr=(25, 80), zr=(-11, 4)):
    """Part 1: plastic strain on the mesh and strain rate with velocity arrows at several times,
    then the surface at each of them."""
    inf = info(source(run))
    picks = [int(inf["frame"][np.argmin(np.abs(inf["t_yr"] / 1e3 - t))]) for t in times_kyr]
    fig = plt.figure(figsize=(13, 2.2 * len(picks) + 3.6), constrained_layout=True)
    gs = fig.add_gridspec(len(picks) + 1, 2, height_ratios=[1] * len(picks) + [1.4])
    axes = [(fig.add_subplot(gs[i, 0]), fig.add_subplot(gs[i, 1])) for i in range(len(picks))]
    axS = fig.add_subplot(gs[len(picks), :])                       # the surface at each of the times
    for (ax, ax2), fr, col in zip(axes, picks, plt.cm.plasma(np.linspace(0.1, 0.85, len(picks)))):
        src = source(run, fr)
        d = load(src, fr)
        pc = draw_plastic_strain(ax, d)
        xs, zs = surface(d)
        ax.set_title(f"t = {d['t_yr'] / 1e3:.0f} kyr", loc="left", fontweight="bold")
        ax.text(0.99, 0.05, f"{len(d['pls'])} elements, relief {zs.max() - zs.min():.1f} km\n"
                f"max plastic strain {d['pls'].max():.1f}, band dips {band_dip(d):.0f}°",
                transform=ax.transAxes, ha="right", va="bottom", fontsize=9,
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#bbb"), zorder=10)
        tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
        pc2 = ax2.tripcolor(tri, facecolors=np.log10(np.maximum(d["srII"], 1e-20)), cmap="viridis", vmin=-16, vmax=-12)
        ax2.plot(xs, zs, color="#222", lw=0.9)
        q = velocity_arrows(ax2, d, (xr[0], xr[1], zr[0], 0), color="w")
        if ax2 is axes[0][1]:
            ax2.quiverkey(q, 0.88, 0.88, 3.0, "3 cm/yr", labelpos="E", coordinates="axes", color="w", labelcolor="#222")
            ax2.set_title("log10 strain rate (1/s) and velocity", loc="left")
        for a in (ax, ax2):
            a.set_xlim(*xr); a.set_ylim(*zr); a.set_aspect("equal")
            mark_reference(a, src)
        ax.set_ylabel("z (km)"); ax2.set_yticklabels([])
        axS.plot(xs, zs, color=col, lw=2, label=source_label(f"{d['t_yr'] / 1e3:.0f} kyr", src))
    for a in axes[-1]:
        a.set_xlabel("x (km)")
    fig.colorbar(pc, ax=[r[0] for r in axes], shrink=0.8, pad=0.01, label="plastic strain", extend="max")
    fig.colorbar(pc2, ax=[r[1] for r in axes], shrink=0.8, pad=0.01, label="log10 strain rate", extend="both")
    axS.set(title="surface topography", xlabel="x (km)", ylabel="z (km)"); axS.set_xlim(*xr)
    axS.grid(alpha=0.3); axS.legend(fontsize=9, loc="upper left")
    return fig


def plot_relief_and_dip(runs, labels=None):
    """Relief and fault-band dip against time for one or more core-complex runs."""
    runs = [Path(r) for r in np.atleast_1d(runs)]
    labels = labels or [r.name for r in runs]
    fig, (axA, axB) = plt.subplots(1, 2, figsize=(11, 3.8), constrained_layout=True)
    for r, lab, col in zip(runs, labels, ARM_COLORS):
        plot_series(axA, r, "t_kyr", "relief_km", lab, color=col, lw=2)
        plot_series(axB, r, "t_kyr", "band_dip_deg", lab, color=col, lw=2)
    axA.set(title="relief: highest minus lowest surface node", xlabel="t (kyr)", ylabel="km")
    axB.set(title="dip of the fault band", xlabel="t (kyr)", ylabel="degrees")
    for a in (axA, axB):
        a.grid(alpha=0.3); a.legend(fontsize=9)
    return fig


def plot_horizons(runs, labels, frame=None, xr=(25, 80), zr=(-11, 4)):
    """Exercise 1: passive horizons (initial depth in 1 km bands) with the fault band shaded,
    then surface, relief against time and the origin depth of the rock now at the surface."""
    runs = [Path(r) for r in runs]
    horiz = np.arange(0, 11, 1.0)
    cmap = ListedColormap(plt.cm.turbo(np.linspace(0.05, 0.95, len(horiz) - 1))); norm = BoundaryNorm(horiz, cmap.N)
    fig = plt.figure(figsize=(11, 2.7 * len(runs) + 3.8), constrained_layout=True)
    gs = fig.add_gridspec(len(runs) + 1, 3, height_ratios=[1] * len(runs) + [1.15])
    axA = fig.add_subplot(gs[len(runs), 0]); axB = fig.add_subplot(gs[len(runs), 1]); axC = fig.add_subplot(gs[len(runs), 2])
    for i, (r, lab) in enumerate(zip(runs, labels)):
        src = source(r, frame)
        fr = frame if frame is not None else frames(src)[-1]
        d = load(src, fr); ax = fig.add_subplot(gs[i, :])
        tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
        sc = ax.tricontourf(tri, d["z0"], levels=horiz, cmap=cmap, norm=norm)
        ax.tricontour(tri, d["z0"], levels=horiz, colors="white", linewidths=0.5, alpha=0.8)
        band = d["pls"] > PLS_BAND
        ax.add_collection(PolyCollection(d["x"][d["c"][band]], facecolors="black", edgecolors="none", alpha=0.4, zorder=3))
        xs, zs = surface(d); ax.plot(xs, zs, color="#222", lw=0.9, zorder=4)
        ex = mtri.LinearTriInterpolator(tri, d["z0"])(xs, zs - 0.3)
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_aspect("equal"); ax.set_ylabel("z (km)"); ax.set_facecolor("#f7f6f2")
        mark_reference(ax, src)
        ax.set_title(f"{lab}: t = {d['t_yr'] / 1e3:.0f} kyr, relief {zs.max() - zs.min():.1f} km, "
                     f"surface rock from {np.nanmax(np.ma.filled(ex, np.nan)):.1f} km depth", loc="left", fontweight="bold", color=ARM_COLORS[i])
        axA.plot(xs, zs, color=ARM_COLORS[i], lw=2)
        axC.plot(xs, np.ma.filled(ex, np.nan), color=ARM_COLORS[i], lw=2)
        plot_series(axB, r, "t_kyr", "relief_km", color=ARM_COLORS[i], lw=2)
        if i < len(runs) - 1:
            ax.set_xticklabels([])
        else:
            ax.set_xlabel("x (km)")
    fig.colorbar(sc, ax=fig.axes[3:], shrink=0.6, pad=0.01, ticks=horiz, label="initial depth (km): passive horizons")
    axA.set(title="surface topography", xlabel="x (km)", ylabel="z (km)"); axA.set_xlim(*xr)
    axB.set(title="relief against time", xlabel="t (kyr)", ylabel="km")
    axC.set(title="exhumation: origin depth of surface rock", xlabel="x (km)", ylabel="initial depth (km)"); axC.set_xlim(*xr); axC.invert_yaxis()
    for a in (axA, axB, axC):
        a.grid(alpha=0.3)
    run_legend(fig, runs, labels)
    return fig


def plot_mesh_comparison(runs, labels, frame=None, xr=(25, 80), zr=(-11, 4)):
    """Exercise 2: plastic strain on the mesh for several runs at one frame, with element and
    remesh counts; then their surfaces at that frame; then element count and maximum plastic
    strain against time, and the elements of each run at that frame split by plastic strain."""
    runs = [Path(r) for r in runs]
    fig = plt.figure(figsize=(12, 2.5 * len(runs) + 7.2), constrained_layout=True)
    gs = fig.add_gridspec(len(runs) + 2, 3, height_ratios=[1] * len(runs) + [1.0, 1.15])
    axT = fig.add_subplot(gs[len(runs), :])
    bars, ticks = [], []
    for i, (r, lab) in enumerate(zip(runs, labels)):
        src = source(r, frame)
        fr = frame if frame is not None else frames(src)[-1]
        d = load(src, fr); ax = fig.add_subplot(gs[i, :])
        pc = draw_plastic_strain(ax, d)
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_ylabel("z (km)")
        nrem = len(remesh_events(source(r)))
        rem = f", {nrem} remeshes" if nrem else ""
        mark_reference(ax, src)
        ax.set_title(f"{lab}: {len(d['pls'])} elements{rem}, smallest edge {element_edge(d).min():.2f} km, "
                     f"max plastic strain {d['pls'].max():.1f}", loc="left", fontweight="bold", color=ARM_COLORS[i], fontsize=9)
        xs, zs = surface(d)
        axT.plot(xs, zs, color=ARM_COLORS[i], lw=2)
        bars.append(element_classes(d)); ticks.append(textwrap.fill(lab, 12, break_long_words=False) + ("\n(reference)" if MARK_REFERENCE and is_reference(src) else ""))
        if i < len(runs) - 1:
            ax.set_xticklabels([])
        else:
            ax.set_xlabel("x (km)")
    fig.colorbar(pc, ax=fig.axes[1:], shrink=0.6, pad=0.01, label="plastic strain", extend="max")
    axT.set(title=f"surface topography at {d['t_yr'] / 1e3:.0f} kyr", xlabel="x (km)", ylabel="z (km)"); axT.set_xlim(*xr); axT.grid(alpha=0.3)
    axA = fig.add_subplot(gs[len(runs) + 1, 0]); axB = fig.add_subplot(gs[len(runs) + 1, 1]); axC = fig.add_subplot(gs[len(runs) + 1, 2])
    bottom = np.zeros(len(runs))
    for k, (name, color) in enumerate([("no plastic strain (< 0.01)", "#dfe9df"), ("softening (0.01 to 0.5)", "#f2c94c"),
                                       ("fully softened (> 0.5)", "#e07b39")]):
        n = np.array([b[k] for b in bars])
        axC.bar(range(len(runs)), n, bottom=bottom, color=color, edgecolor="white", label=name)
        for j in range(len(runs)):
            if n[j] > 60:
                axC.text(j, bottom[j] + n[j] / 2, f"{n[j]}", ha="center", va="center", fontsize=8.5, color="#333")
        bottom += n
    axC.set_xticks(range(len(runs)), ticks, fontsize=8)
    for t, c in zip(axC.get_xticklabels(), ARM_COLORS):
        t.set_color(c)
    axC.set(title=f"elements by plastic strain at {d['t_yr'] / 1e3:.0f} kyr", ylabel="elements")
    axC.legend(fontsize=8, loc="upper left")
    for r, lab, col in zip(runs, labels, ARM_COLORS):
        plot_series(axA, r, "t_kyr", "nelem", color=col, lw=2)
        plot_series(axB, r, "t_kyr", "max_plastic_strain", color=col, lw=2)
    axA.set(title="elements against time", xlabel="t (kyr)", ylabel="elements")
    axB.set(title="maximum plastic strain", xlabel="t (kyr)", ylabel="plastic strain")
    for a in (axA, axB):
        a.grid(alpha=0.3)
    run_legend(fig, runs, labels)
    return fig


def plot_subduction(run, frame_list=None, xr=(70, 330), zr=(-135, 8)):
    """Part 2: material with velocity arrows (left) and log viscosity with isotherms (right)."""
    fr_list = frame_list or frames(source(run))
    fig, axes = plt.subplots(len(fr_list), 2, figsize=(13.5, 3.3 * len(fr_list) + 0.6), constrained_layout=True, squeeze=False)
    for row, fr in enumerate(fr_list):
        src = source(run, fr)
        d = load(src, fr); ax, ax2 = axes[row]
        draw_material(ax, d)
        q = velocity_arrows(ax, d, (xr[0], xr[1], zr[0], 0), n_across=19)
        if row == 0:
            ax.quiverkey(q, 0.84, 0.72, 3.0, "3 cm/yr", labelpos="E", coordinates="axes", color="#444", labelcolor="#222")
        slab = (d["mm"] == 0) | (d["mm"] == 5)
        ax.set_title(f"t = {d['t_yr'] / 1e6:.1f} Myr", loc="left", fontweight="bold", fontsize=13)
        ax.text(0.99, 0.04, f"slab tip {d['mx'][slab, 1].min():.0f} km\n{(d['mm'] == 4).sum()} serpentinite, "
                f"{(d['mm'] == 5).sum()} eclogite markers", transform=ax.transAxes, ha="right", va="bottom",
                fontsize=9.5, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#bbb"), zorder=10)
        tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
        pc = ax2.tripcolor(tri, np.log10(d["visc"]), cmap="viridis", vmin=19, vmax=24, shading="flat", rasterized=True)
        cs = ax2.tricontour(tri, d["T"] - 273, levels=np.arange(200, 1400, 200), colors="w", linewidths=0.7, alpha=0.9)
        if row == 0:
            ax2.clabel(cs, fmt="%d °C", fontsize=8, colors="w", inline=True)
            ax2.set_title("log10 viscosity (Pa s), isotherms every 200 °C", loc="left", fontsize=11)
        xs, zs = surface(d); ax2.plot(xs, zs, color="#222", lw=0.8)
        for a in (ax, ax2):
            a.set_xlim(*xr); a.set_ylim(*zr); a.set_aspect("equal")
            mark_reference(a, src)
        ax.set_ylabel("z (km)"); ax2.set_yticklabels([])
    for a in axes[-1]:
        a.set_xlabel("x (km)")
    axes[0, 0].legend(handles=[Patch(color=MAT_COLORS[m], label=MAT_NAMES[m]) for m in (0, 2, 3, 4, 5)],
                      loc="center left", bbox_to_anchor=(0.01, 0.42), fontsize=9, ncol=2, framealpha=0.95).set_zorder(10)
    fig.colorbar(pc, ax=axes[:, 1], shrink=0.5, pad=0.01, label="log10 viscosity (Pa s)")
    return fig


def plot_subduction_arms(runs, labels, xr=(0, 400), zr=(-118, 8)):
    """Exercise 3: each run at its own last frame across the whole domain, then slab-tip depth,
    trench depth and serpentinite count against time."""
    runs = [Path(r) for r in runs]
    fig = plt.figure(figsize=(13, 3.3 * len(runs) + 3.6), constrained_layout=True)
    gs = fig.add_gridspec(len(runs) + 1, 3, height_ratios=[1] * len(runs) + [0.95])
    for i, (r, lab) in enumerate(zip(runs, labels)):
        src = source(r)
        d = load(src, frames(src)[-1]); ax = fig.add_subplot(gs[i, :])
        draw_material(ax, d)
        q = velocity_arrows(ax, d, (xr[0], xr[1], zr[0], 0), n_across=29)
        if i == 0:
            ax.quiverkey(q, 0.90, 0.72, 3.0, "3 cm/yr", labelpos="E", coordinates="axes", color="#444", labelcolor="#222")
            ax.legend(handles=[Patch(color=MAT_COLORS[m], label=MAT_NAMES[m]) for m in (0, 2, 3, 4, 5)],
                      loc="lower left", bbox_to_anchor=REF_TAG_CLEAR, fontsize=9, ncol=3, framealpha=0.95).set_zorder(10)
        t = d["t_yr"] / 1e6
        ended = "  (the run stopped here)" if abs(t - 5.0) > 0.05 else ""
        xs, zs = surface(d); slab = (d["mm"] == 0) | (d["mm"] == 5)
        zs = zs[(xs > xs.min() + 60) & (xs < xs.max() - 60)]      # as series(): clear of the side walls
        ax.text(0.99, 0.03, f"slab tip {d['mx'][slab, 1].min():.0f} km,  trench {zs.min():.1f} km", transform=ax.transAxes,
                ha="right", va="bottom", fontsize=9.5, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#bbb"), zorder=10)
        mark_reference(ax, src)
        ax.set_title(f"{lab}: t = {t:.1f} Myr, {(d['mm'] == 4).sum()} serpentinite / {(d['mm'] == 5).sum()} eclogite markers{ended}",
                     loc="left", fontweight="bold", color=ARM_COLORS[i])
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_ylabel("z (km)")
        if i < len(runs) - 1:
            ax.set_xticklabels([])
        else:
            ax.set_xlabel("x (km)")
    axA = fig.add_subplot(gs[len(runs), 0]); axB = fig.add_subplot(gs[len(runs), 1]); axC = fig.add_subplot(gs[len(runs), 2])
    for r, lab, col in zip(runs, labels, ARM_COLORS):
        s = plot_series(axA, r, "t_myr", "slab_tip_km", color=col, lw=2)
        plot_series(axB, r, "t_myr", "trench_km", color=col, lw=2)
        plot_series(axC, r, "t_myr", "n_serpentinite", color=col, lw=2)
        if abs(s["t_myr"][-1] - 5.0) > 0.05:
            for a, y in ((axA, s["slab_tip_km"][-1]), (axB, s["trench_km"][-1]), (axC, s["n_serpentinite"][-1])):
                a.plot(s["t_myr"][-1], y, "x", color=col, ms=9, mew=2.5)
    axA.set(title="slab tip depth", xlabel="t (Myr)", ylabel="z (km)")
    axB.set(title="trench depth", xlabel="t (Myr)", ylabel="z (km)")
    axC.set(title="serpentinite markers", xlabel="t (Myr)", ylabel="markers")
    for a in (axA, axB, axC):
        a.grid(alpha=0.3); a.set_xlim(0, 5.1)
    run_legend(fig, runs, labels)
    return fig


def plot_remeshing(run, time_unit="Myr"):
    """How the mesh evolves. Left: elements by plastic-strain class over time, from your run once it
    has written frames (drawn over its faded reference while it is still going), else from the
    reference; the remeshes are marked by trigger only on a reference. Right: the cumulative remesh
    count by trigger. DES prints its remeshes to the screen alone, so they come from the reference,
    which keeps them in remesh.csv, unless the run has its own record."""
    run = Path(run)
    scale = 1e6 if time_unit == "Myr" else 1e3
    rec = run if remesh_events(run) else REFERENCE / run.name     # the run with a record of its remeshes
    events = remesh_events(rec)
    assert events, f"{run} has no record of its remeshes (remesh.csv or solver.log), and no reference of its name does"
    classes = [("no plastic strain (< 0.01)", "#dfe9df"), ("softening (0.01 to pls1)", "#f2c94c"),
               ("fully softened (> pls1)", "#e07b39")]
    shown = source(run)                                            # your finished run, else the reference
    layers = [(shown, 0.3 if partial(run) else 0.95)] + ([(run, 0.95)] if partial(run) else [])
    trig_colors = {"tiny element": "#d95f02", "low quality": "#7570b3", "bottom drift": "#1b9e77", "side-wall drift": "#e7298a", "other": "#666"}
    marks = {"tiny element": "v", "low quality": "o", "bottom drift": "^", "side-wall drift": "s", "other": "x"}
    fig, (ax, ax2) = plt.subplots(1, 2, figsize=(14, 5.4), constrained_layout=True, gridspec_kw={"width_ratios": [2, 1]})
    for src, alpha in layers:
        s = series(src)
        assert "n_pls_none" in s, f"{src}/series.csv predates the element-class columns; rebuild it with src/make_reference.py"
        T = s["t_kyr"] * 1e3 / scale
        ax.stackplot(T, [s["n_pls_none"], s["n_pls_softening"], s["n_pls_softened"]], colors=[c for _, c in classes],
                     alpha=alpha, edgecolor="white", lw=0.5)
        ax.plot(T, s["nelem"], color="k", lw=1.5, alpha=1 if alpha > 0.5 else 0.3)
    T_end = series(shown)["t_kyr"][-1] * 1e3 / scale
    present = [k for k in trig_colors if any(e[1] == k for e in events)]
    marked = is_reference(shown) and not partial(run)              # remesh markers belong on the reference's own curve
    if marked:
        for k in present:
            ev = [e for e in events if e[1] == k]
            ax.scatter([e[0] / scale for e in ev], [e[3] for e in ev], marker=marks[k], s=30, color=trig_colors[k],
                       edgecolors="white", linewidths=0.6, zorder=4)
    ax.set(xlabel=f"t ({time_unit})", ylabel="elements",
           title=f"mesh size by plastic strain, {len(events)} remeshes marked by trigger" if marked else "mesh size by plastic strain")
    ax.set_xlim(0, T_end)
    handles = [Patch(color=c, label=l) for l, c in classes]
    if marked:
        handles += [Line2D([], [], ls="", marker=marks[k], color=trig_colors[k], markeredgecolor="white", ms=7,
                           label=f"remesh triggered by a {k} ({sum(1 for e in events if e[1] == k)})") for k in present]
    if partial(run):
        handles.append(Patch(color="#999", alpha=0.3, label="faded: reference under your run"))
    ax.legend(handles=handles, fontsize=8.5, loc="upper left", framealpha=0.95)
    mark_reference(ax, shown if not partial(run) else run)
    tt = np.array([e[0] / scale for e in events])
    ax2.step(np.r_[0, tt], np.r_[0, np.arange(1, len(tt) + 1)], where="post", color="k", lw=1.8, label=f"all ({len(tt)})")
    for k in present:
        tk = np.array([e[0] / scale for e in events if e[1] == k])
        ax2.step(np.r_[0, tk, T_end], np.r_[0, np.arange(1, len(tk) + 1), len(tk)], where="post", color=trig_colors[k], lw=2, label=f"{k} ({len(tk)})")
    ax2.legend(fontsize=9, loc="upper left")
    mark_reference(ax2, rec, right=True)         # lower left is where the curves start
    ax2.set(xlabel=f"t ({time_unit})", ylabel="remeshes so far", title="cumulative remeshes"); ax2.set_xlim(0, T_end); ax2.grid(alpha=0.3)
    return fig


def draw_viscosity(ax, d, levels=range(200, 1400, 200)):
    """Element log10 viscosity with nodal isotherms (deg C) and the free surface."""
    tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
    pc = ax.tripcolor(tri, np.log10(d["visc"]), vmin=19, vmax=24, cmap="viridis", shading="flat")
    ax.tricontour(tri, d["T"] - 273.15, levels=list(levels), colors="white", linewidths=0.9)
    xs, zs = surface(d)
    ax.plot(xs, zs, color="#222", lw=0.9)
    ax.set_aspect("equal")
    return pc


def plot_stop_convergence(ref, restart, xr=(70, 330), zr=(-135, 8), restart_frame=100):
    """The restart case: the subduction run at its checkpoint frame and the restart at its last frame,
    material and viscosity, then trench depth and forearc high, slab-tip depth, the mean temperature
    of the slab below 60 km and marker counts from 3 Myr on, the restart dashed."""
    ref, restart = Path(ref), Path(restart)
    ref5, restart7 = source(ref, restart_frame), source(restart)
    d5, d7 = load(ref5, restart_frame), load(restart7, frames(restart7)[-1])
    fig = plt.figure(figsize=(16, 13), constrained_layout=True)
    gs = fig.add_gridspec(3, 4, height_ratios=[1, 1, 0.8])
    # one grid for the four maps, its third column holding the viscosity colorbar, so both rows
    # have the same columns and the maps line up
    maps = gs[:2, :].subgridspec(2, 3, wspace=0.04, width_ratios=[1, 1, 0.025])
    axM = [fig.add_subplot(maps[0, 0]), fig.add_subplot(maps[0, 1])]
    axV = [fig.add_subplot(maps[1, 0]), fig.add_subplot(maps[1, 1])]
    for ax in (axM[1], axV[1]):
        ax.set_anchor("E")        # the right-hand maps up against the colorbar column
    t5, t7 = d5["t_yr"] / 1e6, d7["t_yr"] / 1e6
    labels = [f"subduction run at {t5:.0f} Myr, converging at 3.15 cm/yr",
              f"restart at {t7:.0f} Myr, convergence stopped for {t7 - t5:.0f} Myr"]
    for ax, d, lab, run in zip(axM, (d5, d7), labels, (ref5, restart7)):
        draw_material(ax, d)
        q = velocity_arrows(ax, d, (xr[0], xr[1], zr[0], 0), n_across=19)
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_xticklabels([])
        xs, zs = surface(d); slab = (d["mm"] == 0) | (d["mm"] == 5)
        zs = zs[(xs > xs.min() + 60) & (xs < xs.max() - 60)]      # as series(): clear of the side walls
        ax.set_title(lab, loc="left", fontweight="bold")
        mark_reference(ax, run)
        ax.text(0.99, -0.03, f"slab tip {d['mx'][slab, 1].min():.0f} km,  trench {zs.min():.1f} km,  forearc high {zs.max():.1f} km\n"
                      f"{(d['mm'] == 4).sum()} serpentinite / {(d['mm'] == 5).sum()} eclogite markers,  "
                      f"max speed {np.abs(d['vel']).max() * YEAR * 100:.1f} cm/yr",
                      transform=ax.transAxes, ha="right", va="top", fontsize=9.5, color="#333")
    axM[0].quiverkey(q, 0.88, 0.80, 3.0, "3 cm/yr", labelpos="E", coordinates="axes", color="#444", labelcolor="#222")
    axM[0].legend(handles=[Patch(color=MAT_COLORS[m], label=MAT_NAMES[m]) for m in (0, 2, 3, 4, 5)],
                  loc="lower left", bbox_to_anchor=REF_TAG_CLEAR, fontsize=9, ncol=3, framealpha=0.95).set_zorder(10)
    for ax, d in zip(axV, (d5, d7)):
        pc = draw_viscosity(ax, d)
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_xlabel("x (km)")
    axV[0].set_title(f"viscosity and isotherms at {t5:.0f} Myr", loc="left")
    axV[1].set_title(f"the same at {t7:.0f} Myr", loc="left")
    for ax, run in zip(axV, (ref5, restart7)):
        mark_reference(ax, run)
    fig.colorbar(pc, cax=fig.add_subplot(maps[1, 2]), label="log10 viscosity (Pa s)\nisotherms every 200 °C")
    axM[0].set_ylabel("z (km)"); axV[0].set_ylabel("z (km)"); axM[1].set_yticklabels([]); axV[1].set_yticklabels([])
    s_ref, s_re = series(source(ref)), series(restart7)
    t_end = s_re["t_myr"][-1]
    axes = [fig.add_subplot(gs[2, i]) for i in range(4)]
    for ax in axes:
        ax.axvspan(s_ref["t_myr"][-1], t_end, color="#f3e2c6", alpha=0.6, lw=0)
        ax.axvline(s_ref["t_myr"][-1], color="#b35806", ls="--", lw=1)
        ax.grid(alpha=0.3); ax.set_xlabel("t (Myr)"); ax.set_xlim(3.0, t_end + 0.02)
    lines = [(axes[0], "trench_km", "#1b9e77", "trench (deepest node)"), (axes[0], "relief_max_km", "#7570b3", "forearc high (highest node)"),
             (axes[1], "slab_tip_km", "#d95f02", None), (axes[2], "slab_T_deep_C", "#e7298a", None),
             (axes[3], "n_serpentinite", "#5e1a8e", "serpentinite"), (axes[3], "n_eclogite", "#a50f15", "eclogite × 5")]
    for run, ls in ((ref, "-"), (restart, "--")):
        for ax, col, color, _ in lines:
            plot_series(ax, run, "t_myr", col, scale=5 if col == "n_eclogite" else 1, color=color, ls=ls, lw=2)
    for ax in (axes[0], axes[3]):
        ax.legend(handles=[Line2D([], [], color=c, lw=2, label=lab) for a, _, c, lab in lines if a is ax],
                  fontsize=8.5, loc="center left" if ax is axes[0] else "upper left")
    axes[0].set(title="surface between x = 60 and 340 km", ylabel="z (km)")
    axes[1].set(title="slab tip depth", ylabel="z (km)")
    styles = [Line2D([], [], color="#666", lw=2, ls="-", label=source_label("subduction run", ref if partial(ref) else source(ref))),
              Line2D([], [], color="#666", lw=2, ls="--", label=source_label("restart", restart if partial(restart) else restart7))]
    if partial(ref) or partial(restart):
        styles.append(Line2D([], [], color="#666", lw=2, alpha=0.3, label="faded: reference under your run"))
    fig.legend(handles=styles, loc="outside lower center", ncol=len(styles), fontsize=9, frameon=False)   # line styles of all three panels
    axes[2].set(title="mean temperature of the slab below 60 km", ylabel="°C")
    axes[3].set(title="phase-change markers", ylabel="markers")
    for ax in axes:      # y range of what is shown from 3 Myr on, not of the whole series from 0
        y = np.concatenate([l.get_ydata()[l.get_xdata() >= 3.0] for l in ax.get_lines() if l.get_transform() == ax.transData])
        pad = 0.05 * (np.nanmax(y) - np.nanmin(y))
        ax.set_ylim(np.nanmin(y) - pad, np.nanmax(y) + pad)
    axes[0].text(s_ref["t_myr"][-1] + 0.03, axes[0].get_ylim()[0], "vbc_val_x0 = 0", fontsize=9, color="#b35806", va="bottom")
    return fig


def save_figure(fig, stem):
    directory = ROOT / "results" / "figures"
    directory.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(directory / f"{stem}.{ext}")
    return directory / f"{stem}.png"
