"""Small, inspectable helpers for the DES tectonics tutorial notebook.

Everything reads the VTKHDF frames a DES run writes (``output/model.save.NNNNNN.vtkhdf``) plus
its ``output/model.info`` table, with h5py and numpy alone. A run directory is any folder that
holds an ``output/`` subfolder, so your own runs and the supplied reference runs are read the
same way.
"""
from pathlib import Path
import csv
import re

import h5py
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from matplotlib.collections import PolyCollection
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "resources"
REFERENCE = DATA / "reference"
YEAR = 365.2422 * 86400.0           # DES constants.hpp YEAR2SEC
BOUNDZ1 = 32                        # DES constants.hpp: the top-boundary bit of bcflag
PLS_BAND = 0.5                      # an element with more plastic strain than this is "in the fault band"

MAT_NAMES = ["oceanic crust", "cont. crust", "mantle", "sediment", "serpentinite",
             "eclogite", "hydrous mantle", "sediment rock", "metasediment", "schist"]
MAT_COLORS = ["#2166ac", "#d8b365", "#dfe9df", "#f2c94c", "#9b59d0",
              "#d73027", "#66c2a5", "#e6ab02", "#a65628", "#999999"]
ARM_COLORS = ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e"]


def configure_plotting():
    plt.rcParams.update({"font.size": 11, "axes.titlesize": 12, "figure.dpi": 110,
                         "savefig.dpi": 160, "axes.spines.top": False, "axes.spines.right": False})


# ---------------------------------------------------------------- reading a run

def frames(run):
    """Sorted frame numbers of a run directory (its output/model.save.*.vtkhdf files)."""
    run = Path(run)
    return sorted(int(p.name[-13:-7]) for p in (run / "output").glob("model.save.*.vtkhdf"))


def info(run):
    """The .info table: frame, step, time (s), dt (s), wall time (s), nnode, nelem, nseg."""
    a = np.atleast_2d(np.loadtxt(Path(run) / "output/model.info"))
    return dict(frame=a[:, 0].astype(int), step=a[:, 1].astype(int), t_yr=a[:, 2] / YEAR,
                dt_s=a[:, 3], wall_s=a[:, 4], nnode=a[:, 5].astype(int), nelem=a[:, 6].astype(int))


def load(run, frame):
    """One frame: coordinates (km), connectivity, element fields, nodal fields and the markers."""
    with h5py.File(Path(run) / f"output/model.save.{frame:06d}.vtkhdf", "r") as h:
        sr = h["strain-rate"][...]
        d = dict(x=h["coordinate"][...] / 1e3, c=h["connectivity"][...], bc=h["bcflag"][...],
                 pls=h["plastic strain"][...], mat=h["material"][...].astype(int),
                 visc=h["viscosity"][...], T=h["temperature"][...],
                 srII=np.sqrt(0.5 * (sr[:, 0] ** 2 + sr[:, 1] ** 2) + sr[:, 2] ** 2),
                 vel=h["velocity averaged"][...] if "velocity averaged" in h else h["velocity"][...],
                 z0=-h["coord0"][...][:, 1] / 1e3,            # each node's initial depth, km
                 t_yr=float(h["time_yr"][0]))
        if "markerset.coord" in h:
            d["mx"] = h["markerset.coord"][...] / 1e3
            d["mm"] = h["markerset.mattype"][...].astype(int)
    return d


def surface(d):
    """x and z (km) of the free-surface nodes, sorted by x."""
    top = (d["bc"] & BOUNDZ1) != 0
    o = np.argsort(d["x"][top, 0])
    return d["x"][top, 0][o], d["x"][top, 1][o]


def element_edge(d):
    """Equivalent equilateral edge length (km) of every element, from its area."""
    tri = d["x"][d["c"]]
    area = 0.5 * np.abs((tri[:, 1, 0] - tri[:, 0, 0]) * (tri[:, 2, 1] - tri[:, 0, 1])
                        - (tri[:, 2, 0] - tri[:, 0, 0]) * (tri[:, 1, 1] - tri[:, 0, 1]))
    return np.sqrt(4 * area / np.sqrt(3))


def band_dip(d):
    """Dip (degrees) of the fault band: a least-squares line through the centroids of elements
    with plastic strain above PLS_BAND."""
    cen = d["x"][d["c"]].mean(1)
    m = d["pls"] > PLS_BAND
    if m.sum() < 5:
        return np.nan
    return np.degrees(np.arctan(abs(np.polyfit(cen[m, 0], cen[m, 1], 1)[0])))


def series(run):
    """Per-frame summary of a run as a dict of arrays. Reads resources' series.csv when the run
    is a supplied reference (its frames are few and stripped), else computes from every frame."""
    run = Path(run)
    csv_path = run / "series.csv"
    if csv_path.is_file():
        with csv_path.open() as f:
            rows = list(csv.DictReader(f))
        return {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}
    rows = []
    for fr in frames(run):
        d = load(run, fr)
        xs, zs = surface(d)
        row = dict(frame=fr, t_kyr=d["t_yr"] / 1e3, t_myr=d["t_yr"] / 1e6, nelem=len(d["pls"]),
                   crest_km=zs.max(), basin_km=zs.min(), relief_km=zs.max() - zs.min(),
                   max_plastic_strain=d["pls"].max(), band_dip_deg=band_dip(d),
                   trench_km=zs.min(), relief_max_km=zs.max())
        if "mm" in d:
            slab = (d["mm"] == 0) | (d["mm"] == 5)
            row.update(slab_tip_km=d["mx"][slab, 1].min() if slab.any() else np.nan,
                       n_serpentinite=int((d["mm"] == 4).sum()), n_eclogite=int((d["mm"] == 5).sum()))
        rows.append(row)
    return {k: np.array([r.get(k, np.nan) for r in rows]) for k in rows[0]}


def remesh_events(run):
    """(time, trigger, elements before, after) of each remesh, from output/model.runlog, or
    from remesh.csv when the run is a supplied reference (its log is not shipped).
    Time is in kyr for the core-complex runs and Myr for subduction; callers divide."""
    csv_path = Path(run) / "remesh.csv"
    if csv_path.is_file():
        with csv_path.open() as f:
            return [(float(r["time"]), r["trigger"], float(r["nelem_before"]), float(r["nelem_after"]))
                    for r in csv.DictReader(f)]   # element counts are NaN for a remesh that failed
    log = Path(run) / "output/model.runlog"
    if not log.is_file():
        return []
    text = log.read_text(errors="replace")
    triggers = {"tiny element": r"is too small", "low quality": r"is too low",
                "bottom drift": r"too far from the bottom", "side-wall drift": r"too far from the [xy][01] side"}
    out, prev = [], 0
    for m in re.finditer(r"Remeshing starts \(#\d+, step \d+, t = ([0-9.eE+-]+) yr\)", text):
        before = text[prev:m.start()]
        last = max(((h.start(), k) for k, pat in triggers.items() for h in re.finditer(pat, before)), default=None)
        nm = re.compile(r"New mesh \([^)]*\): nodes \d+ -> \d+, elements (\d+) -> (\d+)").search(text, m.end())
        a, b = (int(nm.group(1)), int(nm.group(2))) if nm else (np.nan, np.nan)
        out.append((float(m.group(1)), last[1] if last else "other", a, b))
        prev = m.end()
    return out


# ---------------------------------------------------------------- running DES

def velocity_arrows(ax, d, box, n_across=20, ref_cm_yr=3.0, span=0.64, color="#444"):
    """Arrows of the velocity on a regular grid inside box (x0, x1, z0, z1 in km)."""
    x0, x1, z0, z1 = box
    dl = (x1 - x0) / n_across
    gx, gz = np.meshgrid(np.arange(x0 + dl / 2, x1, dl), np.arange(z0 + dl / 2, z1, dl))
    tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
    u = mtri.LinearTriInterpolator(tri, d["vel"][:, 0] * 100 * YEAR)(gx, gz)
    w = mtri.LinearTriInterpolator(tri, d["vel"][:, 1] * 100 * YEAR)(gx, gz)
    keep = ~(np.ma.getmaskarray(u) | np.ma.getmaskarray(w))
    gx, gz, u, w = gx[keep], gz[keep], np.asarray(u)[keep], np.asarray(w)[keep]
    speed = np.hypot(u, w)
    f = np.where(speed > 2 * ref_cm_yr, 2 * ref_cm_yr / np.maximum(speed, 1e-30), 1.0)
    return ax.quiver(gx, gz, u * f, w * f, color=np.where(speed > 2 * ref_cm_yr, "#b2182b", color).tolist(),
                     angles="xy", scale_units="xy", scale=ref_cm_yr / (span * dl), width=0.0025,
                     headwidth=3.5, headlength=4, zorder=6)


def draw_plastic_strain(ax, d, vmax=3, mesh=True):
    """Plastic strain on the mesh with the surface drawn; returns the mappable."""
    tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
    pc = ax.tripcolor(tri, facecolors=d["pls"], cmap="magma", vmin=0, vmax=vmax,
                      edgecolors="w" if mesh else "none", linewidth=0.15)
    xs, zs = surface(d)
    ax.plot(xs, zs, color="#222", lw=0.9)
    ax.set_facecolor("#f7f6f2")
    ax.set_aspect("equal")
    return pc


def draw_material(ax, d, markers=(4, 5)):
    """Element material with the chosen marker materials as dots and the surface drawn."""
    ax.add_collection(PolyCollection(d["x"][d["c"]], facecolors=[MAT_COLORS[m] for m in d["mat"]], edgecolors="none"))
    for m, col in zip(markers, ("#5e1a8e", "#a50f15")):
        sel = d["mm"] == m
        ax.plot(d["mx"][sel, 0], d["mx"][sel, 1], ".", ms=2.4, color=col, rasterized=True)
    xs, zs = surface(d)
    ax.plot(xs, zs, color="#222", lw=0.8)
    ax.set_facecolor("#f7f6f2")
    ax.set_aspect("equal")


def plot_core_complex(run, times_kyr=(25, 50, 75, 100), xr=(25, 80), zr=(-11, 4)):
    """Part 1: plastic strain on the mesh and strain rate with velocity arrows at several times."""
    inf = info(run)
    picks = [int(inf["frame"][np.argmin(np.abs(inf["t_yr"] / 1e3 - t))]) for t in times_kyr]
    fig, axes = plt.subplots(len(picks), 2, figsize=(13, 2.2 * len(picks) + 0.6), constrained_layout=True, squeeze=False)
    for (ax, ax2), fr in zip(axes, picks):
        d = load(run, fr)
        pc = draw_plastic_strain(ax, d)
        xs, zs = surface(d)
        ax.set_title(f"t = {d['t_yr'] / 1e3:.0f} kyr", loc="left", fontweight="bold")
        ax.text(0.99, 0.05, f"{len(d['pls'])} elements, relief {zs.max() - zs.min():.1f} km\n"
                f"max plastic strain {d['pls'].max():.1f}, band dips {band_dip(d):.0f}°",
                transform=ax.transAxes, ha="right", va="bottom", fontsize=9,
                bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#bbb"), zorder=10)
        tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
        pc2 = ax2.tripcolor(tri, facecolors=np.log10(np.maximum(d["srII"], 1e-20)), cmap="viridis", vmin=-16, vmax=-12)
        ax2.plot(xs, zs, color="#222", lw=0.9)
        q = velocity_arrows(ax2, d, (xr[0], xr[1], zr[0], 0), color="w")
        if ax2 is axes[0][1]:
            ax2.quiverkey(q, 0.88, 0.88, 3.0, "3 cm/yr", labelpos="E", coordinates="axes", color="w", labelcolor="#222")
            ax2.set_title("log10 strain rate (1/s) and velocity", loc="left")
        for a in (ax, ax2):
            a.set_xlim(*xr); a.set_ylim(*zr); a.set_aspect("equal")
        ax.set_ylabel("z (km)"); ax2.set_yticklabels([])
    for a in axes[-1]:
        a.set_xlabel("x (km)")
    fig.colorbar(pc, ax=[r[0] for r in axes], shrink=0.8, pad=0.01, label="plastic strain", extend="max")
    fig.colorbar(pc2, ax=[r[1] for r in axes], shrink=0.8, pad=0.01, label="log10 strain rate", extend="both")
    return fig


def plot_relief_and_dip(runs, labels=None):
    """Relief and fault-band dip against time for one or more core-complex runs."""
    runs = [Path(r) for r in np.atleast_1d(runs)]
    labels = labels or [r.name for r in runs]
    fig, (axA, axB) = plt.subplots(1, 2, figsize=(11, 3.8), constrained_layout=True)
    for r, lab, col in zip(runs, labels, ARM_COLORS):
        s = series(r)
        axA.plot(s["t_kyr"], s["relief_km"], color=col, lw=2, label=lab)
        axB.plot(s["t_kyr"], s["band_dip_deg"], color=col, lw=2, label=lab)
    axA.set(title="relief: highest minus lowest surface node", xlabel="t (kyr)", ylabel="km")
    axB.set(title="dip of the fault band", xlabel="t (kyr)", ylabel="degrees")
    for a in (axA, axB):
        a.grid(alpha=0.3); a.legend(fontsize=9)
    return fig


def plot_horizons(runs, labels, frame=None, xr=(25, 80), zr=(-11, 4)):
    """Exercise 1: passive horizons (initial depth in 1 km bands) with the fault band shaded,
    then surface, relief against time and the origin depth of the rock now at the surface."""
    runs = [Path(r) for r in runs]
    horiz = np.arange(0, 11, 1.0)
    cmap = ListedColormap(plt.cm.turbo(np.linspace(0.05, 0.95, len(horiz) - 1))); norm = BoundaryNorm(horiz, cmap.N)
    fig = plt.figure(figsize=(11, 2.7 * len(runs) + 3.8), constrained_layout=True)
    gs = fig.add_gridspec(len(runs) + 1, 3, height_ratios=[1] * len(runs) + [1.15])
    axA = fig.add_subplot(gs[len(runs), 0]); axB = fig.add_subplot(gs[len(runs), 1]); axC = fig.add_subplot(gs[len(runs), 2])
    for i, (r, lab) in enumerate(zip(runs, labels)):
        fr = frame if frame is not None else frames(r)[-1]
        d = load(r, fr); ax = fig.add_subplot(gs[i, :])
        tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
        sc = ax.tricontourf(tri, d["z0"], levels=horiz, cmap=cmap, norm=norm)
        ax.tricontour(tri, d["z0"], levels=horiz, colors="white", linewidths=0.5, alpha=0.8)
        band = d["pls"] > PLS_BAND
        ax.add_collection(PolyCollection(d["x"][d["c"][band]], facecolors="black", edgecolors="none", alpha=0.4, zorder=3))
        xs, zs = surface(d); ax.plot(xs, zs, color="#222", lw=0.9, zorder=4)
        ex = mtri.LinearTriInterpolator(tri, d["z0"])(xs, zs - 0.3)
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_aspect("equal"); ax.set_ylabel("z (km)"); ax.set_facecolor("#f7f6f2")
        ax.set_title(f"{lab}: t = {d['t_yr'] / 1e3:.0f} kyr, relief {zs.max() - zs.min():.1f} km, "
                     f"surface rock from {np.nanmax(np.ma.filled(ex, np.nan)):.1f} km depth", loc="left", fontweight="bold", color=ARM_COLORS[i])
        axA.plot(xs, zs, color=ARM_COLORS[i], lw=2, label=lab)
        axC.plot(xs, np.ma.filled(ex, np.nan), color=ARM_COLORS[i], lw=2)
        s = series(r); axB.plot(s["t_kyr"], s["relief_km"], color=ARM_COLORS[i], lw=2)
        if i < len(runs) - 1:
            ax.set_xticklabels([])
        else:
            ax.set_xlabel("x (km)")
    fig.colorbar(sc, ax=fig.axes[3:], shrink=0.6, pad=0.01, ticks=horiz, label="initial depth (km): passive horizons")
    axA.set(title="surface topography", xlabel="x (km)", ylabel="z (km)"); axA.set_xlim(*xr)
    axB.set(title="relief against time", xlabel="t (kyr)", ylabel="km")
    axC.set(title="exhumation: origin depth of surface rock", xlabel="x (km)", ylabel="initial depth (km)"); axC.set_xlim(*xr); axC.invert_yaxis()
    for a in (axA, axB, axC):
        a.grid(alpha=0.3)
    axA.legend(fontsize=8.5, loc="upper left")
    return fig


def plot_mesh_comparison(runs, labels, frame=None, xr=(25, 80), zr=(-11, 4)):
    """Exercise 2: plastic strain on the mesh for several runs at one frame, with element and
    remesh counts; then element count and maximum plastic strain against time."""
    runs = [Path(r) for r in runs]
    fig = plt.figure(figsize=(11, 2.5 * len(runs) + 3.6), constrained_layout=True)
    gs = fig.add_gridspec(len(runs) + 1, 2, height_ratios=[1] * len(runs) + [1.15])
    for i, (r, lab) in enumerate(zip(runs, labels)):
        fr = frame if frame is not None else frames(r)[-1]
        d = load(r, fr); ax = fig.add_subplot(gs[i, :])
        pc = draw_plastic_strain(ax, d)
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_ylabel("z (km)")
        nrem = len(remesh_events(r))
        rem = f", {nrem} remeshes" if nrem else ""
        ax.set_title(f"{lab}: {len(d['pls'])} elements{rem}, smallest edge {element_edge(d).min():.2f} km, "
                     f"max plastic strain {d['pls'].max():.1f}", loc="left", fontweight="bold", color=ARM_COLORS[i], fontsize=10)
        if i < len(runs) - 1:
            ax.set_xticklabels([])
        else:
            ax.set_xlabel("x (km)")
    fig.colorbar(pc, ax=fig.axes, shrink=0.6, pad=0.01, label="plastic strain", extend="max")
    axA = fig.add_subplot(gs[len(runs), 0]); axB = fig.add_subplot(gs[len(runs), 1])
    for r, lab, col in zip(runs, labels, ARM_COLORS):
        s = series(r)
        axA.plot(s["t_kyr"], s["nelem"], color=col, lw=2, label=lab)
        axB.plot(s["t_kyr"], s["max_plastic_strain"], color=col, lw=2, label=lab)
    axA.set(title="elements against time", xlabel="t (kyr)", ylabel="elements")
    axB.set(title="maximum plastic strain", xlabel="t (kyr)", ylabel="plastic strain")
    for a in (axA, axB):
        a.grid(alpha=0.3)
    axA.legend(fontsize=8.5, loc="upper left")
    return fig


def plot_subduction(run, frame_list=None, xr=(70, 330), zr=(-135, 8)):
    """Part 2: material with velocity arrows (left) and log viscosity with isotherms (right)."""
    fr_list = frame_list or frames(run)
    fig, axes = plt.subplots(len(fr_list), 2, figsize=(13.5, 3.3 * len(fr_list) + 0.6), constrained_layout=True, squeeze=False)
    for row, fr in enumerate(fr_list):
        d = load(run, fr); ax, ax2 = axes[row]
        draw_material(ax, d)
        q = velocity_arrows(ax, d, (xr[0], xr[1], zr[0], 0), n_across=19)
        if row == 0:
            ax.quiverkey(q, 0.84, 0.72, 3.0, "3 cm/yr", labelpos="E", coordinates="axes", color="#444", labelcolor="#222")
        slab = (d["mm"] == 0) | (d["mm"] == 5)
        ax.set_title(f"t = {d['t_yr'] / 1e6:.1f} Myr", loc="left", fontweight="bold", fontsize=13)
        ax.text(0.99, 0.04, f"slab tip {d['mx'][slab, 1].min():.0f} km\n{(d['mm'] == 4).sum()} serpentinite, "
                f"{(d['mm'] == 5).sum()} eclogite markers", transform=ax.transAxes, ha="right", va="bottom",
                fontsize=9.5, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#bbb"), zorder=10)
        tri = mtri.Triangulation(d["x"][:, 0], d["x"][:, 1], d["c"])
        pc = ax2.tripcolor(tri, np.log10(d["visc"]), cmap="viridis", vmin=19, vmax=24, shading="flat", rasterized=True)
        cs = ax2.tricontour(tri, d["T"] - 273, levels=np.arange(200, 1400, 200), colors="w", linewidths=0.7, alpha=0.9)
        if row == 0:
            ax2.clabel(cs, fmt="%d °C", fontsize=8, colors="w", inline=True)
            ax2.set_title("log10 viscosity (Pa s), isotherms every 200 °C", loc="left", fontsize=11)
        xs, zs = surface(d); ax2.plot(xs, zs, color="#222", lw=0.8)
        for a in (ax, ax2):
            a.set_xlim(*xr); a.set_ylim(*zr); a.set_aspect("equal")
        ax.set_ylabel("z (km)"); ax2.set_yticklabels([])
    for a in axes[-1]:
        a.set_xlabel("x (km)")
    axes[0, 0].legend(handles=[Patch(color=MAT_COLORS[m], label=MAT_NAMES[m]) for m in (0, 2, 3, 4, 5)],
                      loc="center left", bbox_to_anchor=(0.01, 0.42), fontsize=9, ncol=2, framealpha=0.95).set_zorder(10)
    fig.colorbar(pc, ax=axes[:, 1], shrink=0.5, pad=0.01, label="log10 viscosity (Pa s)")
    return fig


def plot_subduction_arms(runs, labels, xr=(0, 400), zr=(-118, 8)):
    """Exercise 3: each run at its own last frame across the whole domain, then slab-tip depth,
    trench depth and serpentinite count against time."""
    runs = [Path(r) for r in runs]
    fig = plt.figure(figsize=(13, 3.3 * len(runs) + 3.6), constrained_layout=True)
    gs = fig.add_gridspec(len(runs) + 1, 3, height_ratios=[1] * len(runs) + [0.95])
    for i, (r, lab) in enumerate(zip(runs, labels)):
        d = load(r, frames(r)[-1]); ax = fig.add_subplot(gs[i, :])
        draw_material(ax, d)
        q = velocity_arrows(ax, d, (xr[0], xr[1], zr[0], 0), n_across=29)
        if i == 0:
            ax.quiverkey(q, 0.90, 0.72, 3.0, "3 cm/yr", labelpos="E", coordinates="axes", color="#444", labelcolor="#222")
            ax.legend(handles=[Patch(color=MAT_COLORS[m], label=MAT_NAMES[m]) for m in (0, 2, 3, 4, 5)],
                      loc="lower left", fontsize=9, ncol=5, framealpha=0.95).set_zorder(10)
        t = d["t_yr"] / 1e6
        ended = "  (the run stopped here)" if abs(t - 5.0) > 0.05 else ""
        ax.set_title(f"{lab}: t = {t:.1f} Myr, {(d['mm'] == 4).sum()} serpentinite / {(d['mm'] == 5).sum()} eclogite markers{ended}",
                     loc="left", fontweight="bold", color=ARM_COLORS[i])
        ax.set_xlim(*xr); ax.set_ylim(*zr); ax.set_ylabel("z (km)")
        if i < len(runs) - 1:
            ax.set_xticklabels([])
        else:
            ax.set_xlabel("x (km)")
    axA = fig.add_subplot(gs[len(runs), 0]); axB = fig.add_subplot(gs[len(runs), 1]); axC = fig.add_subplot(gs[len(runs), 2])
    for r, lab, col in zip(runs, labels, ARM_COLORS):
        s = series(r)
        axA.plot(s["t_myr"], s["slab_tip_km"], color=col, lw=2, label=lab)
        axB.plot(s["t_myr"], s["trench_km"], color=col, lw=2)
        axC.plot(s["t_myr"], s["n_serpentinite"], color=col, lw=2)
        if abs(s["t_myr"][-1] - 5.0) > 0.05:
            for a, y in ((axA, s["slab_tip_km"][-1]), (axB, s["trench_km"][-1]), (axC, s["n_serpentinite"][-1])):
                a.plot(s["t_myr"][-1], y, "x", color=col, ms=9, mew=2.5)
    axA.set(title="slab tip depth", xlabel="t (Myr)", ylabel="z (km)")
    axB.set(title="trench depth", xlabel="t (Myr)", ylabel="z (km)")
    axC.set(title="serpentinite markers", xlabel="t (Myr)", ylabel="markers")
    for a in (axA, axB, axC):
        a.grid(alpha=0.3); a.set_xlim(0, 5.1)
    axA.legend(fontsize=8.5)
    return fig


def plot_remeshing(run, time_unit="Myr"):
    """How the mesh evolves: elements by plastic-strain class over time with each remesh marked
    by its trigger, and the cumulative remesh count by trigger. Needs the run's frames and runlog."""
    scale = 1e6 if time_unit == "Myr" else 1e3
    events = remesh_events(run)
    inf = info(run)
    classes = [("no plastic strain (< 0.01)", lambda e: e < 0.01, "#dfe9df"),
               ("softening (0.01 to pls1)", None, "#f2c94c"),
               ("fully softened (> pls1)", None, "#e07b39")]
    T, counts = [], []
    fr_list = frames(run)
    pls1 = 0.1 if "subduction" in str(run) else 0.5
    for fr in fr_list:
        d = load(run, fr); e = d["pls"]
        T.append(d["t_yr"] / scale)
        counts.append([(e < 0.01).sum(), ((e >= 0.01) & (e < pls1)).sum(), (e >= pls1).sum()])
    T = np.array(T); counts = np.array(counts).T
    trig_colors = {"tiny element": "#d95f02", "low quality": "#7570b3", "bottom drift": "#1b9e77", "side-wall drift": "#e7298a", "other": "#666"}
    marks = {"tiny element": "v", "low quality": "o", "bottom drift": "^", "side-wall drift": "s", "other": "x"}
    fig, (ax, ax2) = plt.subplots(1, 2, figsize=(14, 5.4), constrained_layout=True, gridspec_kw={"width_ratios": [2, 1]})
    ax.stackplot(T, counts, colors=[c for _, _, c in classes], alpha=0.95, edgecolor="white", lw=0.5)
    ax.plot(inf["t_yr"] / scale, inf["nelem"], color="k", lw=1.5)
    present = [k for k in trig_colors if any(e[1] == k for e in events)]
    for k in present:
        ev = [e for e in events if e[1] == k]
        ax.scatter([e[0] / scale for e in ev], [e[3] for e in ev], marker=marks[k], s=30, color=trig_colors[k],
                   edgecolors="white", linewidths=0.6, zorder=4)
    ax.set(xlabel=f"t ({time_unit})", ylabel="elements", title=f"mesh size by plastic strain, {len(events)} remeshes marked by trigger")
    ax.set_xlim(0, T[-1])
    ax.legend(handles=[Patch(color=c, label=l) for l, _, c in classes] +
              [Line2D([], [], ls="", marker=marks[k], color=trig_colors[k], markeredgecolor="white", ms=7,
                      label=f"remesh triggered by a {k} ({sum(1 for e in events if e[1] == k)})") for k in present],
              fontsize=8.5, loc="upper left", framealpha=0.95)
    tt = np.array([e[0] / scale for e in events])
    if len(tt):
        ax2.step(np.r_[0, tt], np.r_[0, np.arange(1, len(tt) + 1)], where="post", color="k", lw=1.8, label=f"all ({len(tt)})")
        for k in present:
            tk = np.array([e[0] / scale for e in events if e[1] == k])
            ax2.step(np.r_[0, tk, T[-1]], np.r_[0, np.arange(1, len(tk) + 1), len(tk)], where="post", color=trig_colors[k], lw=2, label=f"{k} ({len(tk)})")
        ax2.legend(fontsize=9, loc="upper left")
    else:
        ax2.text(0.5, 0.5, "no output/model.runlog:\nremesh triggers come from the log", ha="center", va="center", transform=ax2.transAxes)
    ax2.set(xlabel=f"t ({time_unit})", ylabel="remeshes so far", title="cumulative remeshes by trigger"); ax2.set_xlim(0, T[-1]); ax2.grid(alpha=0.3)
    return fig


def save_figure(fig, stem):
    directory = ROOT / "results" / "figures"
    directory.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(directory / f"{stem}.{ext}")
    return directory / f"{stem}.png"
